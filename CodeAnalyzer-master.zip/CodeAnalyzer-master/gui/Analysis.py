'''
Created on Jan 9, 2017

@author: Frank She
'''
import json
import os
import tkinter as tk
from tkinter import filedialog, messagebox

from lib.gui_functions import *

# Check box text
checkbox_text_dict = json.load(open('config/guiCheckbox.json'))
# Activities with issue level
act2issue_dict = json.load(open('config/issueLevel.json'))

class Analysis(tk.Toplevel):
    def __init__(self, master, title, function):
        super().__init__(master)
        self.parent=master
        self.title(title)
        self.directory = ''
        self.main_file = ''
        self.function = function
        # check item name -> check item gui variable
        self.checkitem_dict = dict()
        # issue level -> group item gui variable
        self.checkgroup_dict = dict()
        # To control group check
        self.issue2act_dict = dict()
        # Issue leve set
        self.issue_set = set(act2issue_dict.values())
        # Initial issue level lists
        for issue_level in self.issue_set:
            self.issue2act_dict[issue_level] = list()
        for item, level in act2issue_dict.items():
            self.issue2act_dict[level].append(item)
        # Initial varaibles for checkbox
        for item in act2issue_dict.keys():
            self.checkitem_dict[item] = tk.BooleanVar()
            self.checkitem_dict[item].set(True)
        self.add_widgets()

    def add_widgets(self):

        self.folder_entry = tk.Entry(self, width=60)
        self.select_folder = create_general_button(
            self, 'Select Folder', self.select_folder_dialog)

        self.main_file_entry = tk.Entry(self, width=60)
        self.select_main_file = create_general_button(
            self, 'Select Main File', self.select_main_dialog)

        self.start = create_general_button(self, 'Start', self.start_process)
        self.options = create_general_button(self, 'Options', self.options_dialog)
        self.back = create_quit_button(self, 'Back', self.back_to_main)
        self.outputChecklist = tk.BooleanVar()
        self.checklist_cb = create_checkbox(self, 'Output Check List', self.outputChecklist)
        self.protocol('WM_DELETE_WINDOW', self.back_to_main)

        widget_grid(self.select_folder, 0, 0)
        widget_grid(self.folder_entry,  0, 1, 2, tk.N + tk.S)
        widget_grid(self.select_main_file, 1, 0)
        widget_grid(self.main_file_entry, 1, 1, 2, tk.N + tk.S)
        widget_grid(self.start,         2, 0)
        widget_grid(self.options,       2, 1)
        widget_grid(self.checklist_cb,  2, 2)
        widget_grid(self.back,          3, 2)

    def back_to_main(self):
        self.destroy()
        self.parent.root.deiconify()

    def select_folder_dialog(self):
        self.directory = filedialog.askdirectory()
        self.folder_entry.delete(0, len(self.folder_entry.get()))
        self.folder_entry.insert(0, self.directory)

    def select_main_dialog(self):
        self.main_file = os.path.basename(filedialog.askopenfilename())
        self.main_file_entry.delete(0, len(self.main_file_entry.get()))
        self.main_file_entry.insert(0, self.main_file)
        
    def options_dialog(self):
        # Generate Options Panel
        options_frame = tk.Toplevel()
        options_frame.title('Options')

        # Issue level set
        self.issue_set = set(act2issue_dict.values())
        
        # define top label
        level_label = create_label(options_frame, 'Groups')
        general_label = create_label(options_frame, 'Items', 'LightSkyBlue')

        row=0
        col=0
        max_line = 21

        widget_grid(level_label, row, col, len(
            self.issue_set) // (max_line-1) + 1, tk.W + tk.E)
        row+=1
        for level in self.issue_set:
            self.checkgroup_dict[level] = tk.BooleanVar()
            self.checkgroup_dict[level].set(True)
            checkbox = create_checkbox(
                options_frame, 
                level + ' Group', 
                self.checkgroup_dict[level], 
                command=self.check_group)
            widget_grid(checkbox, row, col)
            row+=1
            if row == max_line:
                row = 1
                col +=1
        row = 0
        col +=1

        widget_grid(general_label, row, col, len(
            checkbox_text_dict) // (max_line-1) + 1, tk.W + tk.E)
        row +=1
        for item, explanation in checkbox_text_dict.items():
            checkbox = create_checkbox(
                options_frame, explanation, self.checkitem_dict[item])
            widget_grid(checkbox, row, col)
            row+=1
            if row == max_line:
                row = 1
                col+= 1
        close = create_quit_button(options_frame, 'Apply', options_frame.destroy)
        widget_grid(close, max_line, col)

    def check_group(self):
        for level, value in self.checkgroup_dict.items():
            for item in self.issue2act_dict[level]:
                self.checkitem_dict[item].set(value.get())

    def start_process(self):
        check_item_list = list()
        for item, value in self.checkitem_dict.items():
            if value.get():
                check_item_list.append(item)
        if self.folder_entry.get() == '':
            messagebox.showerror('Error','Please select or input a folder')
            return
        self.directory = self.folder_entry.get()

        if not os.path.isdir(self.directory):
            messagebox.showerror('Error', 'Folder not found')
            return

        self.function(self.directory, check_item_list, self.outputChecklist.get(), self.main_file)
        messagebox.showinfo('Complete', 'Please check report folder for output')
