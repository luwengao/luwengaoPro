'''
Created on Jan 9, 2017

@author: Frank She
'''
import tkinter as tk
import json
import os

from math import ceil
from lib.gui_functions import *
from tkinter import filedialog, messagebox

# Get activity list
activity_all_dict = json.load(
    open('config/guiInvestigationActivityDict.json'))
activity_list = activity_all_dict.keys()
property_list = json.load(
    open('config/guiInvestigationProperties.json'))

class Investigation(tk.Toplevel):
    def __init__(self, master, title, function):
        super().__init__(master)
        self.parent = master
        self.title(title)
        self.directory = ''
        self.function = function
        self.acitivity_var = dict()
        self.property_var = dict()

        self.add_widgets()

    def add_widgets(self):
        self.folder_entry = tk.Entry(self, width=60)
        self.select_folder = create_general_button(
            self, 'Select Folder', self.select_folder_dialog)
        self.start = create_general_button(self, 'Start', self.start_process)
        self.options = create_general_button(self, 'Options', self.options_dialog)
        self.output_package_stats = tk.BooleanVar()        
        self.package_stats = create_checkbox(self, 'Output Package Stats', self.output_package_stats) 
        self.back = create_quit_button(self, 'Back', self.back_to_main)
        self.protocol('WM_DELETE_WINDOW', self.back_to_main)

        self.act_label = create_plain_label(self, 'Activity')
        self.act_input = tk.Entry(self, width=60)
        self.prop_label = create_plain_label(self, 'Property')
        self.prop_input = tk.Entry(self, width=60)

        widget_grid(self.select_folder, 0, 0)
        widget_grid(self.folder_entry,  0, 1, 2, tk.N + tk.S)
        widget_grid(self.act_label,     1, 0, 1, tk.N + tk.S)
        widget_grid(self.act_input,     1, 1, 2, tk.N + tk.S)
        widget_grid(self.prop_label,    2, 0, 1, tk.N + tk.S)
        widget_grid(self.prop_input,    2, 1, 2, tk.N + tk.S)
        widget_grid(self.start,         3, 0)
        widget_grid(self.options,       3, 1)
        widget_grid(self.package_stats, 3, 2)
        widget_grid(self.back,          4, 1)

    def back_to_main(self):
        self.destroy()
        self.parent.root.deiconify()

    def select_folder_dialog(self):
        self.directory = filedialog.askdirectory()
        self.folder_entry.delete(0, len(self.folder_entry.get()))
        self.folder_entry.insert(0, self.directory)
        
        
    def options_dialog(self):
        # Generate Options Panel
        options_frame = tk.Toplevel()
        options_frame.title('Options')
        
        activity_label = create_label(options_frame, 'Activities')
        property_label = create_label(options_frame, 'Properties', 'LightSkyBlue')
        max_line = 25
        row=0
        col=0
        widget_grid(activity_label, row, col, ceil(
            len(activity_list) / (max_line - 1)), tk.W + tk.E)

        row+=1
        for item in activity_list:
            self.acitivity_var[item] = tk.BooleanVar()
            checkbox = create_checkbox(
                options_frame, 
                activity_all_dict[item],
                self.acitivity_var[item])
            # self.options_dict[level] = checkbox
            widget_grid(checkbox, row, col)
            row+=1
            if row == max_line:
                row  = 1
                col += 1
        row = 0
        col +=1
        widget_grid(property_label, row, col, 
                    ceil(len(property_list) / (max_line - 1)), tk.W + tk.E)
        row +=1
        for item in property_list:
            self.property_var[item]=tk.BooleanVar()
            checkbox=create_checkbox(
                options_frame, item, self.property_var[item])
            widget_grid(checkbox, row, col)
            # self.options_dict[item] = checkbox
            row+=1
            if row == max_line:
                row = 1
                col+= 1
        close = create_quit_button(options_frame, 'Apply', options_frame.destroy)
        if row == 1:
            col -= 1
        widget_grid(close, max_line, col)

    def start_process(self):
        check_acts = list()
        check_props= list()

        for act, value in self.acitivity_var.items():
            if value.get():
                check_acts.append(act)
        
        for prop, value in self.property_var.items():
            if value.get():
                check_props.append(prop)

        if self.act_input.get():
            inputed_act = [act.strip() for act in self.act_input.get().split(',')]
        else:
            inputed_act = []
        
        if self.prop_input.get():
            inputed_prop = [prop.strip() for prop in self.prop_input.get().split(',')]
        else:
            inputed_prop = []

        check_acts = check_acts + inputed_act

        if not (check_acts and (check_props or inputed_prop)):
            messagebox.showwarning('Warning', 'No activities or properties input or selected')

        if self.folder_entry.get() == '':
            messagebox.showerror('Error', 'Please select or input a folder')
            return

        self.directory = self.folder_entry.get()

        if not os.path.isdir(self.directory):
            messagebox.showerror('Error', 'Folder not found')
            return

        self.function(self.directory, check_acts, check_props, self.output_package_stats.get(), inputed_prop)
        messagebox.showinfo('Complete', 'Please check report folder for output')
