'''
Created on Jan 10, 2017

@author: Frank She
'''
import tkinter as tk
import sys

from gui.Analysis import Analysis
from gui.Investigation import Investigation
from lib.gui_functions import *

class MainFrame(tk.Frame):
    def __init__(self, master, func_dict):
        super().__init__(master)
        self.root = master
        self.func_dict = func_dict
        self.create_widgets()
        self.pack()

    def create_widgets(self):
        self.analyze = create_general_button(
            self, 
            'Analyze a Project',
            self.do_analysis)
        self.investigate = create_general_button(
            self,
            'Investigate a Project',
            self.do_investigation)
        self.quit = create_quit_button(
            self, 
            "QUIT", 
            self.quit_main)
        widget_grid(self.analyze,     0, 0)
        widget_grid(self.investigate, 1, 0)
        widget_grid(self.quit,        2, 0)

    def do_analysis(self):
        self.root.withdraw()
        app = Analysis(self, 'Analyze', self.func_dict['analyze_code'])
        app.mainloop()

    def do_investigation(self):
        self.root.withdraw()
        app = Investigation(self, 'Investigation', self.func_dict['investigate_code'])
        app.mainloop()

    def quit_main(self):
        self.destroy()
        sys.exit(0)
