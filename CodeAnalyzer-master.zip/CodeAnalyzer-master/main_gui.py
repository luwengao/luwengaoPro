'''
Created on Jan 8, 2018

@author: Frank She
'''

import datetime
import json
import logging
import os
import shutil
import tkinter as tk

import xlsxwriter

from gui.MainFrame import MainFrame
from lib.init_funcs import extractXamlFiles, startCheck
from lib.investigate_funcs import (write_activities_details_gui,
                                   write_project_stat,
                                   write_project_package_stat)
from lib.write_checklist_funcs import writeChecklist
from lib.write_xlsx_funcs import writeResultAsXlsx
import UiObject.Act as Act

# Get execute path
exec_path = os.getcwd()

if not os.path.exists('report'):
    os.mkdir('report')
if not os.path.exists('log'):
    os.mkdir('log')

# Current Working Directory

log_fmt = '%(asctime)s %(levelname)s:%(message)s'
log_header_fmt = '%(message)s'

log_file = exec_path + '/log/' + str(datetime.date.today()) + '.log'

console = logging.StreamHandler()

logging.basicConfig(
    format=log_fmt, 
    datefmt='%H:%M:%S',
    level=logging.DEBUG,
    handlers=[
        logging.FileHandler(log_file),
        console
    ])

logger = logging.getLogger(__name__)

settings = json.load(open("config/settings.json"))
VERSION = settings['Version']

console.setFormatter(logging.Formatter(log_header_fmt))
logger.info("_"*73)
logger.info(r"  ____          _           _                _                    ")
logger.info(r" / ___|___   __| | ___     / \   _ __   __ _| |_   _ _______ _ __ ")
logger.info(r"| |   / _ \ / _` |/ _ \   / _ \ | '_ \ / _` | | | | |_  / _ \ '__|")
logger.info(r"| |__| (_) | (_| |  __/  / ___ \| | | | (_| | | |_| |/ /  __/ |   ")
logger.info(r" \____\___/ \__,_|\___| /_/   \_\_| |_|\__,_|_|\__, /___\___|_|   ")
logger.info(r"                                               |___/              " + VERSION)
logger.info("Let me know if any questions.")
logger.info("Email: calvin.he@uipath.com")
logger.info("Please be noted that the check result can only be used for reference.")
logger.info("_"*73)
console.setFormatter(logging.Formatter(log_fmt, datefmt='%H:%M:%S'))

report_path = exec_path + "/report/"

def analyze_code(folder, checkitems, outputChecklist, main_file):
    project_folder = folder
    if main_file=='':
        main_file='Main.xaml'
    project_files_dict = extractXamlFiles(project_folder, main_file)
    project = startCheck(project_files_dict, project_folder)

    output_folder = report_path + project.projectFolder
    if os.path.exists(output_folder):
        shutil.rmtree(output_folder)
    os.mkdir(output_folder)
    writeResultAsXlsx(project, report_path, VERSION, checkitems)

    if outputChecklist:
        writeChecklist(project, exec_path, settings["robotFolder"])

def investigate_code(folder, check_acts, check_props, output_package_stats, inputed_prop):

    if inputed_prop:
        Act.Act.inputProperties = inputed_prop

    project_folder = folder
    project_files_dict = dict()
    project_files_dict['main_exist'] = False
    project_files_dict['project.json'] = False
    project_files_dict['main'] = ''
    project_files_dict["root"] = list()
    cw_list = list()

    for root, dirs, files in os.walk(project_folder):
        logger.info('Loading folder: ' + root)
        for file in files:
            if file.endswith('.xaml'):
                cw_list.append(os.path.join(root, file))

    project_files_dict["common"] = cw_list

    project = startCheck(project_files_dict, project_folder)

    workbook = xlsxwriter.Workbook(report_path + "/Investigation_" + VERSION +
                                "_" + project.projectFolder + "_" + str(datetime.date.today()) + ".xlsx")

    write_project_stat(workbook, project)
    if output_package_stats:
        write_project_package_stat(workbook, project)
    # write_issue_list(workbook, project)
    check_props = check_props + inputed_prop
    if check_acts and check_props:
        write_activities_details_gui(workbook, project, check_acts, check_props)
    workbook.close()

root = tk.Tk()
func_dict = dict()
func_dict['analyze_code'] = analyze_code
func_dict['investigate_code'] = investigate_code
main = MainFrame(root, func_dict)
main.master.title("Code Analyzer " + VERSION)
main.mainloop()
