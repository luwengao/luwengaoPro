'''
Created on Oct 28, 2017

@author: Frank She
'''
import datetime
import os
import re

from graphviz import Digraph

def draw_flowchart(project, cwd, version):
    
    # Draw workflow diagram
    if not project.main_wf is None:
        diagram = Digraph('Workflow Diagram', filename = cwd + project.projectFolder + '/' + project.projectFolder + '_Workflow_Diagram_' + version + str(datetime.date.today()))
        add_sub_diagram(diagram, project.invoked_wf_dict, project.main_wf.xamlFile)
        diagram.render()

    for workflow in project.wfList:
        graph = Digraph('G', filename=cwd + project.projectFolder + '/workflow/' + workflow.xamlFile + '_' + version + str(datetime.date.today()))
        graph.attr('node', shape='record', fontsize = '12')
        root_act = workflow.rootAct
        add_sub_graph(graph, root_act, None)
        graph.render()

def add_sub_diagram(diagram, invoked_wf_dict, xamlFile, level=0):
    if level > 10:
        add_workflow_edge(diagram, xamlFile, "Reach max recursion")
    elif xamlFile in invoked_wf_dict.keys():
        for file in invoked_wf_dict[xamlFile]:
            add_workflow_edge(diagram, xamlFile, file)
            add_sub_diagram(diagram, invoked_wf_dict, file, level=level+1)
 

def add_workflow_edge(diagram, from_wf, to_wf):
    diagram.edge(from_wf, to_wf)
    add_workflow_node(diagram, from_wf)
    add_workflow_node(diagram, to_wf)


def add_workflow_node(diagram, xamlFile):
    # print(os.path.basename(xamlFile))
    diagram.node(xamlFile, os.path.basename(xamlFile))


def add_sub_graph(graph, act, from_act):
    graph.node_attr.update(style='filled')
    last_act = None
    first_act = None
    if act.hasChildActs:
        sgraph = Digraph(name='cluster_' + act.id)
        sgraph.attr(label=act.name)
        sgraph.attr(color='blue')
        sgraph.node_attr.update(style='filled')

        # Get first act of this container
        pre_child_act = act.childActs[0]

        if pre_child_act.isContainer:
            last_act = add_sub_graph(sgraph, pre_child_act, from_act)
            if last_act == pre_child_act:
                last_act = None
            first_act = get_first_act(pre_child_act)
        else:
            add_node(sgraph, pre_child_act)

        for child in act.childActs[1:]:
            if child.isContainer:
                if last_act is None:
                    last_act = add_sub_graph(sgraph, child, pre_child_act)
                else:
                    last_act = add_sub_graph(sgraph, child, last_act)
            else:
                if last_act is None:
                    add_edge_within_graph(sgraph, pre_child_act, child)
                else:
                    add_edge_between_graph(sgraph, last_act, child)
                    add_node(sgraph, child)
                    last_act = None
            pre_child_act = child        
        graph.subgraph(sgraph)
    else:
        add_node(graph, act)
        last_act = act

    # Connect to from_act
    first_act = get_first_act(act)
    if not from_act is None:
        if is_in_same_container(from_act.parent_act, act.parent_act):
            add_edge_between_graph(graph, from_act, first_act)

    # Return last act of the container
    if last_act is None:
        return pre_child_act
    else:
        return last_act



def add_edge_within_graph(graph, act, next_act):
    # print('connect from {0} to {1} within graph'.format(act.id, next_act.id))
    graph.edge(act.id, next_act.id)
    add_node(graph, act)
    add_node(graph, next_act)

def add_edge_between_graph(graph, act, next_act):
    # print('connect from {0} to {1} between graph'.format(act.id, next_act.id))
    graph.edge(act.id, next_act.id)
    # add_node(graph, act)

def add_node(graph, act):
    # print('add node ' + act.id)
    act.name = re.sub(r'{.*}', '', act.name)
    graph.node(act.id, '{' + act.name + '|' + act.displayName + '|' + act.index + '}')

def get_first_act(act):
    if act.isContainer:
        if act.hasChildActs:
            return get_first_act(act.childActs[0])
        else:
            return act
    else:
        return act

def is_in_same_container(act, container):
    if act is None:
        return False
    else:
        if act == container:
            return True
        else:
            return is_in_same_container(act.parent_act, container)
