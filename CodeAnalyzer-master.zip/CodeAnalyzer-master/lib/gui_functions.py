'''
Created on Jan 9, 2017

@author: Frank She
'''
import tkinter as tk

# Define Button in same style


def create_general_button(frame, text, command):
    return tk.Button(frame, text=text, width=30, padx=1, pady=1, command=command)

def create_quit_button(frame, text, command):
    return tk.Button(frame, text=text, width=30, padx=1, pady=1, fg='red', command=command)

def create_checkbox(frame, text, variable, command=None):
    return tk.Checkbutton(frame, text=text, variable=variable, command=command)

def create_label(frame, text, bg='grey'):
    return tk.Label(frame, text=text, relief=tk.RIDGE, bd=1, bg=bg)

def create_plain_label(frame, text):
    return tk.Label(frame, text=text)

def widget_grid(widget, row, col, columnspan=1, align=tk.W):
    widget.grid(row=row, column=col, padx=1, pady=1,
                sticky=align, columnspan=columnspan)
