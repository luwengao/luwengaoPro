import json
import os
import re

from UiObject.Project import Project
import csv

def getCheckListTemplate(rootdir):
    regex = re.compile('^checklist_template_([0-9_]*ver[0-9_\.]*)\.xlsx$')
    for root, dirs, files in os.walk(rootdir):
      for file in files:
        m = regex.match(file)
        if m:
            return file, m.group(1)

    return None, None

checkDict = json.load(open("config/checklistRowNum.json"))

def writeChecklist(pj, exePath, robotFolder):
    others = list()
    result = list()
    checkSet = list(checkDict.keys())

    isWriteExisting = False
    isCitrixExisting = False
    isParallelExisting = False

    for key, value in pj.counter.items():
        if "WRITE" in key.upper() and "WRITELINE" not in key.upper():
            isWriteExisting = True
        elif key.upper() == "PARALLEL":
            isParallelExisting = True
        elif "IMAGE" in key.upper() and "SAVEIMAGE" != key.upper() and "LOADIMAGE" != key.upper():
            isCitrixExisting = True

    if isWriteExisting:
        checkSet.remove("checkWriting")
    else:
        result.append("{0}|N/A||".format(checkDict["checkWriting"]))
        checkSet.remove("checkWriting")

    if isParallelExisting:
        checkSet.remove("checkParallel")
    else:
        result.append("{0}|N/A||".format(checkDict["checkParallel"]))
        checkSet.remove("checkParallel")

    isCommonExisting = len(pj.projectFilesDict["common"]) > 0

#    for file in pj.wfList:
#        if "\\" in file.xamlFile or "CW_" in file.xamlFile:
#            isCommonExisting = True

    if not isCommonExisting:
        result.append("{0}|N/A||".format(checkDict["checkLogMessage"]))
        checkSet.remove("checkLogMessage")


    fixPattern = ["checkMainFile","checkWorkflowName","checkCommonWorkflowPrefix","checkDisplayName","checkName",
                  "checkScreenshot", "checkTopLayerIsFlowchart","checkAnnotation","checkTerminateWorkflow","checkLogMessage","checkActNotInCatch"]
    lambdaPatter = {
            "checkFilePath" : (lambda l : "checkFilePath" in checkSet  and  issue == "checkFilePath" and not ("PROGRAM" in desc.upper() or "NOTES" in desc.upper()))
        }

    isPasswordUsed = False
    #begin loop over issue list
    for record_id, record in pj.project_result_dict.items():
        issue = record["issue"]
        level = record["level"]
        path = record["internal"]
        desc = record["explanation"]
        xaml = record["xamlFile"]

        if issue == "checkHardcodedPassword":
            isPasswordUsed = True
        # for other sheet
        if "checkNestedSequence" in checkSet and issue == "checkNestedSequence" :
            others.append("Maintainability|Other|Redundant nested sequence is used for the same sequential operations|Remove the redundant sequence|{0}\nE.g.\n{1}|INDIRECT".format(xaml, path))
            checkSet.remove("checkNestedSequence")

        if "checkArgsInMain" in checkSet and issue == "checkArgsInMain" :
            others.append("Maintainability|Other|Arguments are not supposed in Main.xaml|Remove arguments from main|Main.xaml|INDIRECT")
            checkSet.remove("checkArgsInMain")

        if "checkExternalRef" in checkSet and issue == "checkExternalRef" :
            others.append("Operability|Other|Referred resource is out of project's scope.|Recommend to include the referred xaml files into the project.|{0}\nE.g.\n{1}|INDIRECT".format(xaml, path))
            checkSet.remove("checkExternalRef")

        if "checkProjectJson" in checkSet and issue == "checkProjectJson" :
            others.append("Operability|Other|project.json doesn't exist or is unreadable.|To include the project.json file.||INDIRECT")
            checkSet.remove("checkProjectJson")

        for checkItem in fixPattern:
            if checkItem in checkSet and issue == checkItem :
                result.append("{0}|NG|(Refer to IssueList)|(Refer to IssueList)".format(checkDict[checkItem]))
                checkSet.remove(checkItem)

#         if "checkWorkflowName" in checkSet and issue == "checkWorkflowName" :
#             result.Add("{0}|NG|(Refer to IssueList)|(Refer to IssueList)".format(checkDict["checkWorkflowName"]))
#             checkSet.Remove("checkWorkflowName")
#
#         if  ("checkCommonWorkflowPrefix")in checkSet  and issue == "checkCommonWorkflowPrefix" :
#             result.append("{0}|NG|(Refer to IssueList)|(Refer to IssueList)".format(checkDict["checkCommonWorkflowPrefix"]))
#             checkSet.remove("checkCommonWorkflowPrefix")
#
#         if  "checkDisplayName" in checkSet and issue == "checkDisplayName":
#             result.append("{0}|NG|(Refer to IssueList)|(Refer to IssueList)\n{1}".format(checkDict["checkDisplayName"],path))
#             checkSet.remove("checkDisplayName")
#
#         if "checkName" in checkSet and  issue == "checkName" :
#             result.append("{0}|NG|(Refer to IssueList)|(Refer to IssueList)".format(checkDict["checkName"]))
#             checkSet.remove("checkName")

        if "checkFilePath" in checkSet  and  issue == "checkFilePath" and not ("PROGRAM" in desc.upper() or "NOTES" in desc.upper()):
            result.append("{0}|NG|path is hardcoded|{1}\n{2}\n{3}\n(Refer to IssueList)".format(checkDict["checkFilePath"],xaml,path,desc))
            checkSet.remove("checkFilePath")

        if "checkFilePath2" in checkSet  and  issue == "checkFilePath" and not ("PROGRAM" in desc.upper() or "NOTES" in desc.upper()):
            result.append("{0}|NG|path is hardcoded|{1}\n{2}\n{3}\n(Refer to IssueList)".format(checkDict["checkFilePath2"],xaml,path,desc))
            checkSet.remove("checkFilePath2")

#         if "checkScreenshot" in checkSet and issue == "checkScreenshot" :
#             result.append("{0}|NG|(Refer to IssueList)|(Refer to IssueList)".format(checkDict["checkScreenshot"]))
#             checkSet.remove("checkScreenshot")

        if "checkGetEnvPath" in checkSet and issue == "checkFilePath" and "USER" in desc.upper() :
            result.append("{0}|NG|(Refer to IssueList)|{1}\n{2}\n{3}\n(Refer to IssueList)".format(checkDict["checkGetEnvPath"],xaml,path,desc))
            checkSet.remove("checkGetEnvPath")

        if "checkPassword" in checkSet and (issue == "checkGetPassword") :
            result.append("{0}|NG|(Refer to IssueList)|({1}\n{2}\nRefer to IssueList)".format(checkDict["checkPassword"],xaml,path))
            checkSet.remove("checkPassword")

        if "checkSequenceLog" in checkSet and (issue == "checkSequenceStartLog" or issue == "checkSequenceEndLog") :
            result.append("{0}|NG|(Refer to IssueList)|(Refer to IssueList)".format(checkDict["checkSequenceLog"]))
            checkSet.remove("checkSequenceLog")

        if "checkErrorLogWithoutThrow" in checkSet and issue == "checkErrorLogWithoutThrow" :
            result.append("{0}|NG|(Refer to IssueList)|{1}\n{2}\n(Refer to IssueList)".format(checkDict["checkErrorLogWithoutThrow"],xaml,path))
            checkSet.remove("checkErrorLogWithoutThrow")

#         if "checkTopLayerIsFlowchart" in checkSet and issue == "checkTopLayerIsFlowchart" :
#             result.append("{0}|NG|(Refer to IssueList)|(Refer to IssueList)".format(checkDict["checkTopLayerIsFlowchart"]))
#             checkSet.remove("checkTopLayerIsFlowchart")

        if "checkUnused" in checkSet and (issue == "checkUnusedVar" or issue == "checkUnusedAct"):
            result.append("{0}|NG|(Refer to IssueList)|(Refer to IssueList)".format(checkDict["checkUnused"]))
            checkSet.remove("checkUnused")


        if "checkDelay" in checkSet and ("checkDelay" in issue and issue != "checkDelayWithAnnotation" ) and level == "ToBeFixed" :
            result.append("{0}|NG|(Refer to IssueList)|(Refer to IssueList)".format(checkDict["checkDelay"]))
            checkSet.remove("checkDelay")

#         if "checkAnnotation" in checkSet and issue == "checkAnnotation" :
#             result.append("{0}|NG|(Refer to IssueList)|(Refer to IssueList)".format(checkDict["checkAnnotation"]))
#             checkSet.remove("checkAnnotation")

        if "checkCitrix" in checkSet and issue == "checkCitrix" :
            result.append("{0}|NG|citrix activity should not be used in non-citrix application, unless UI element activities not applicable.\nPlease use UI element activities|{1}\n{2}\n(Refer to IssueList)".format(checkDict["checkCitrix"],xaml,path))
            checkSet.remove("checkCitrix")

    #end loop

    #code analyzer
    if "checkErrorLogWithoutThrow" in checkSet and not "Error" in pj.logCounter.keys():
        result.append("{0}|N/A|(Refer to IssueList)|(Refer to IssueList)".format(checkDict["checkErrorLogWithoutThrow"]))
        checkSet.remove("checkErrorLogWithoutThrow")

    if "checkCitrix" in checkSet and not isCitrixExisting:
        result.append("{0}|N/A|(Refer to IssueList)|(Refer to IssueList)".format(checkDict["checkCitrix"]))
        checkSet.remove("checkCitrix")

    if "Warn" not in pj.logCounter.keys() :
        result.append("{0}|N/A|(Refer to IssueList)|(Refer to IssueList)".format(checkDict["checkWarnLog"]))

    if "checkPassword" in checkSet and not isPasswordUsed:
        result.append("{0}|OK||".format(checkDict["checkPassword"]))

    #potential OK List
    okList = ["checkMainFile","checkWorkflowName","checkCommonWorkflowPrefix","checkDisplayName","checkName","checkFilePath", "checkFilePath2",
              "checkScreenshot","checkGetEnvPath","checkSequenceLog","checkErrorLogWithoutThrow","checkTopLayerIsFlowchart","checkUnused",
              "checkDelay","checkAnnotation","checkCitrix","checkTerminateWorkflow","checkLogMessage","checkActNotInCatch"]

    for item in okList:
        if item in checkSet:
            result.append("{0}|OK||".format(checkDict[item]))

    csvOutput = exePath + '/report/' + pj.projectFolder + '/checklist.csv'
    with open(csvOutput, 'w', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile, delimiter=',',lineterminator='\n',quoting=csv.QUOTE_ALL)
        for line in result:
            row = line.split("|")
            writer.writerow(row)

    csvOutput2 = exePath + '/report/' + pj.projectFolder + '/others.csv'
    with open(csvOutput2, 'w', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile, delimiter=',',lineterminator='\n',quoting=csv.QUOTE_ALL)
        for line in others:
            row = line.split("|")
            writer.writerow(row)

    #write excel
    templateFile, verion = getCheckListTemplate(exePath + "/template")
    templateFile = exePath + "/template/" + templateFile
    filename = (exePath + "/report/" + pj.projectFolder + "/RPA レビューチェックリスト_{0}_"+ pj.projectFolder + ".xlsx").format(verion)

    os.chdir(robotFolder)
    #cmd = "UiRobot.exe /file:\"{0}/template/WriteCheckList.xaml\" /input:\"{'templateFile':'{1}','csvFile' : '{2}', 'checklistFile':'{3}', 'otherCsvFile':'{4}'}\"".format(exePath, templateFile, csvOutput, csvOutput2)
    cmd = "UiRobot.exe /file:\"" + exePath +"/template/WriteCheckList.xaml\" /input:\"{'templateFile':'" + templateFile + "','csvFile' : '" + csvOutput + "', 'checklistFile':'" + filename + "','otherCsvFile':'" + csvOutput2 + "'}\""
    cmd = cmd.replace("\\","/")
    os.system(cmd)
    print("Done.")
