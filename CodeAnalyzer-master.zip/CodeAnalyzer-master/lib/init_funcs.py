'''
Created on Oct 28, 2017

@author: Frank She
'''
import glob
import json
import logging
import os
import sys
import time
from xml.etree import ElementTree

from UiObject.Act import Act, extractRootArgDict
from UiObject.Project import Project
from UiObject.Workflow import Workflow

logger = logging.getLogger(__name__)

def inputProjectFolder():
    projectFolder = input(
        "Please input the project folder, or input exit to end the program.\n")

    if projectFolder == "exit":
        sys.exit(0)

    if not os.path.isdir(projectFolder):
        logger.error("The folder doesn't exist. Please check the path and try again")
        sys.exit(1)

    return projectFolder


def removeNamespaces(xamlstr):
    xamlstr = xamlstr.replace("sap2010:", "")
    xamlstr = xamlstr.replace("x:Key", "xKey")
    xamlstr = xamlstr.replace("x:", "")
    xamlstr = xamlstr.replace("sap:", "")
    xamlstr = xamlstr.replace("ui:", "")
    xamlstr = xamlstr.replace("sads:", "")
    xamlstr = xamlstr.replace("scg:", "")
    xamlstr = xamlstr.replace("this:", "")
    xamlstr = xamlstr.replace(
        " xmlns=\"http://schemas.microsoft.com/netfx/2009/xaml/activities\"\n", "")
    return xamlstr


def extractXamlFiles(strProjectFolder, main_file='Main.xaml'):
    # Get all files in the folder
    os.chdir(strProjectFolder)
    project_files_dict = dict()
    root_file_list = glob.glob('*.xaml')
    project_files_dict['main_exist'] = True

    # Read project.json file
    if os.path.isfile('project.json'):
        logger.info('Loading project.json file.')
        project_files_dict['project.json'] = True
        try:
            project_config_dict = json.load(
                open('project.json', 'r', encoding='utf-8-sig'))
            if "main" in project_config_dict.keys():
                main_file = project_config_dict['main']
        except Exception as e:
            logger.warning(e)
            logger.warning('project.json cannot be loaded')
            project_files_dict['project.json'] = False
        if not os.path.isfile(main_file):
            project_files_dict['main_exists'] = False
    else:
        project_files_dict['project.json'] = False
    
    if main_file in root_file_list:
        logger.debug('Remove main file: ' + main_file)
        root_file_list.remove(main_file)
    
    logger.info('main file is ' + main_file)
    project_files_dict['main'] = main_file

    root_file_list_copy = root_file_list[:]
    for file in root_file_list_copy:
        if file.startswith("~"):
            logger.debug('Remove temp file: ' + file)
            root_file_list.remove(file)
    common_file_list = glob.glob('*/*.xaml')
    
    # Remove temporary file
    common_file_list_copy = common_file_list[:]
    for file in common_file_list_copy:
        if file.startswith("~"):
            logger.debug('Remove temp common file: ' + file)
            common_file_list.remove(file)
    
    # Change CW_ to common workflow
    root_file_list_copy = root_file_list[:]
    for file in root_file_list_copy:
        if file.startswith('CW_'):
            logger.debug("Recognize '{0}' as common workflow.".format(file))
            root_file_list.remove(file)
            common_file_list.append(file)
    project_files_dict["root"] = root_file_list
    project_files_dict["common"] = common_file_list
    return project_files_dict


def readXamlFile(strFileName):
    # logger.info("Reading " + strFileName)
    xamlFile = open(strFileName, "r", encoding="utf-8")
    xamlstr = xamlFile.read()
    xamlstr = removeNamespaces(xamlstr)
    return xamlstr


def buildWorkflow(xamlFile, xamlType):
    '''
    Reads a XAML file and constructs its XML tree representation.
    Initializes and returns a Workflow object based on the first activity of the XAML file (root activity).
    '''
    
    xamlstr = readXamlFile(xamlFile)
    # create XML tree from read XAML file
    xamlRootNode = ElementTree.fromstring(xamlstr)
    # extract sequence node
    seqNode = xamlRootNode.find('Sequence')
    # extract StateMachine node
    smNode = xamlRootNode.find('StateMachine')
    # extract Flowchart
    fcNode = xamlRootNode.find('Flowchart')
    # extract TryCatch
    tcNode = xamlRootNode.find('TryCatch')

    if not seqNode is None:
        rootAct = Act(seqNode.tag, seqNode.attrib, 'r', None, seqNode)
        argDict = extractRootArgDict(rootAct, xamlRootNode)
        rootAct.setArgDict(argDict)
        return Workflow(rootAct, xamlstr, xamlFile, xamlType)
    elif not fcNode is None:
        rootAct = Act(fcNode.tag, fcNode.attrib, 'r', None, fcNode)
        argDict = extractRootArgDict(rootAct, xamlRootNode)
        rootAct.setArgDict(argDict)
        return Workflow(rootAct, xamlstr, xamlFile, xamlType)
    elif not smNode is None:
        rootAct = Act(smNode.tag, smNode.attrib, 'r', None, smNode)
        argDict = extractRootArgDict(rootAct, xamlRootNode)
        rootAct.setArgDict(argDict)
        return Workflow(rootAct, xamlstr, xamlFile, xamlType)
    elif not tcNode is None:
        rootAct = Act(tcNode.tag, tcNode.attrib, 'r', None, tcNode)
        argDict = extractRootArgDict(rootAct, xamlRootNode)
        rootAct.setArgDict(argDict)
        return Workflow(rootAct, xamlstr, xamlFile, xamlType)

def startCheck(projectFilesDict, strProjectFolder):
    wf_list = list()
    root_file_list = projectFilesDict['root']
    common_file_list = projectFilesDict['common']
    main_file = projectFilesDict['main']

    file_num = len(root_file_list)+len(common_file_list)
    processed_num = 0

    if main_file != '' and os.path.isfile(main_file):
        processed_num+= 1
        file_num += 1
        logger.info(loading_progress(processed_num, file_num, main_file))
        main_wf = buildWorkflow(main_file, 'main')
        if not main_wf is None:
            wf_list.append(main_wf)
    else:
        logger.warning("Main file doesn't exist.")

    start_time = time.time()

    # Multi Thread
    # thread_list = list()
    # logger.info("Start reading sub workflows:")
    # for root_file in root_file_list:
    #     t = threading.Thread(target=thread_build_workflow, 
    #                          args=(root_file, 'root', wf_list))
    #     thread_list.append(t)
    
    # logger.info("Start reading common workflows:")
    # for common_file in common_file_list:
    #     t = threading.Thread(target=thread_build_workflow,
    #                          args=(common_file, 'common', wf_list))
    #     thread_list.append(t)

    # for thread in thread_list:
    #     thread.start()
    
    # for thread in thread_list:
    #     thread.join()   

    #Multi Processing

    # def file_multiProcessing(file_list, type_str, wf_list):
    #     for file in file_list:
    #         thread_build_workflow(file, 'root', wf_list)

    # for file_list in [root_file_list[::3], root_file_list[1::3], root_file_list[2::3]]:
    #     job = multiprocessing.Process(
    #         target=file_multiProcessing, args=(file_list, 'root', wf_list))
    #     job.start()
    #     job.join()

    # for file_list in [common_file_list[::3], common_file_list[1::3], common_file_list[2::3]]:
    #     job = multiprocessing.Process(
    #         target=file_multiProcessing, args=(file_list, 'common', wf_list))
    #     job.start()
    #     job.join()

    for root_file in root_file_list:
        processed_num += 1
        logger.info(loading_progress(processed_num, file_num, root_file))
        thread_build_workflow(root_file, 'root', wf_list)

    for common_file in common_file_list:
        processed_num += 1
        logger.info(loading_progress(processed_num, file_num, common_file))
        thread_build_workflow(common_file, 'common', wf_list)

    logger.info("Elapsed time: " + str(round(time.time()-start_time,2)) + " second")

    project = Project(wf_list, strProjectFolder, projectFilesDict)
    return project

def thread_build_workflow(file, type_str, wf_list):
    wf = buildWorkflow(file, type_str)
    if wf is None:
        return
    wf_list.append(wf)

def loading_progress(processed_num, total, message):
    progress = str(int(processed_num/total*100)).rjust(3) + '%'
    processed_num = str(processed_num).rjust(len(str(total)))
    limited_message = message
    if len(message) > 35:
        limited_message = '..' + message[-33:]
    return progress + ' | (' + processed_num + '/' + str(total) + ') ' + 'Loading: ' + limited_message
