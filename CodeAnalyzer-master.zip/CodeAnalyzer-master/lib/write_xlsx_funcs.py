'''
Created on Oct 28, 2017

@author: Frank She
'''
import datetime
import glob
import json
import os
import re
import logging
from xml.etree import ElementTree

import xlsxwriter

from UiObject.Act import Act, extractRootArgDict
from UiObject.Project import Project
from UiObject.Workflow import Workflow

skipCheckItems = json.load(open("config/skipCheckItems.json"))
checkItems = json.load(open("config/issueLevel.json")).keys()

logger = logging.getLogger(__name__)

def writeResultAsXlsx(pj, cwd, version, checkitems=checkItems):
    logger.info('Creating CodeAnalzyer report.')
    workbook = xlsxwriter.Workbook(cwd  + pj.projectFolder + "/CodeAnalyzer_"+ version + "_" + pj.projectFolder + "_" + str(datetime.date.today()) + ".xlsx")
    wfList = pj.wfList
    
    headlineFormat = workbook.add_format()
    headlineFormat.set_bold()
    headlineFormat.set_font_size(20)
    
    chapterFormat = workbook.add_format()
    chapterFormat.set_bold()
    
    tableHeaderFormat = workbook.add_format()
    tableHeaderFormat.set_bold()
    tableHeaderFormat.set_border()
    
    tableFormat = workbook.add_format()
    tableFormat.set_border()
    
    check_resultFormat = workbook.add_format()
    
    # Yellow
    shouldFormat = workbook.add_format()
    shouldFormat.set_bg_color('FFFF66')
    # Gray
    ignoreFormat = workbook.add_format()
    ignoreFormat.set_bg_color('666666')
    # Red
    mustFormat = workbook.add_format()
    mustFormat.set_bg_color('FF6666')
    # Orange
    tobeConfirmedFormat = workbook.add_format()
    tobeConfirmedFormat.set_bg_color("FFCC99")
    # Cyan
    doubleCheckFormat = workbook.add_format()
    doubleCheckFormat.set_bg_color("99FFFF")
    # Gray font
    grayFontFormat = workbook.add_format()
    grayFontFormat.set_font_color("999999")

    logger.info('Output Overview sheet.')
    worksheet = workbook.add_worksheet("Overview")
    worksheet.set_column(0, 1, 5)
    worksheet.set_column(2, 2, 20)
    worksheet.set_row(0, 25)
    row = 0
    col = 0
    
    worksheet.write(row, col, pj.projectFolder, headlineFormat)
    row += 2
    col += 1
    
    # Output Workflow
    worksheet.write(row, col, "Workflow Stat", chapterFormat)
    row += 2
    col += 1

    worksheet.write(row, col, "Workflow Type", tableHeaderFormat)
    worksheet.write(row, col + 1, "Count", tableHeaderFormat)
    row += 1

    worksheet.write(row, col, 'Sub Workflow', tableFormat)
    worksheet.write(
        row, col + 1, len(pj.projectFilesDict['root']), tableFormat)
    row += 1

    worksheet.write(row, col, 'Common Workflow', tableFormat)
    worksheet.write(
        row, col + 1, len(pj.projectFilesDict['common']), tableFormat)
    row += 1


    row += 1
    col -= 1

    # Output stat
    worksheet.write(row, col, "Activity Stat", chapterFormat)
    row += 2
    col += 1
    
    worksheet.write(row, col, "Activity", tableHeaderFormat)
    worksheet.write(row, col+1, "Count", tableHeaderFormat)
    row += 1
    
    for key, value in pj.counter.items():
        worksheet.write(row, col, key, tableFormat)
        worksheet.write(row, col+1, value, tableFormat)
        row += 1
    
    row += 1
    
    worksheet.write(row, col, "Log Level", tableHeaderFormat)
    worksheet.write(row, col+1, "Count", tableHeaderFormat)    
    row += 1
    
    for key, value in pj.logCounter.items():
        worksheet.write(row, col, key, tableFormat)
        worksheet.write(row, col+1, value, tableFormat)
        row += 1        
    
    row += 1
    col -= 1

    # Output File List
    worksheet.write(row, col, "File List", chapterFormat)    
    
    row += 2
    col += 1
    
    # filename -> sheetname
    sheetname_dict = dict()
    for file in pj.wfList:
        sheetname = cleanUpSheetName(file.xamlFile)
        if sheetname not in sheetname_dict.values():
            sheetname_dict[file.xamlFile] = sheetname
        else:
            num = 1
            while sheetname in sheetname_dict.values() and num < 10:
                sheetname = sheetname[:-1]+str(num)
                num += 1
            if num == 10:
                logger.error('Too many similar sheetname for ' + file.xamlFile)
                return
            sheetname_dict[file.xamlFile] = sheetname

    for filename, sheetname in sheetname_dict.items():
        url = "internal:'" + cleanUpSheetName(sheetname) + "'!A1"
        worksheet.write_url(row, col, url, string=filename)
        row += 1
    
    row += 1
    col -= 1

    # Output project check result
    worksheet.write(row, col, "Check Points", chapterFormat)
    
    row += 2
    col += 1

    for item, res in pj.check_result.items():
        worksheet.write(row, col, item, shouldFormat)
        worksheet.write(row, col+1, res)
        row += 1
        
    for wf in pj.wfList:
        for key, value  in wf.check_result.items():
            if key in ["checkCommonWorkflowPrefix", "checkWorkflowName"]:
                worksheet.write(row, col, key, shouldFormat)
                worksheet.write(row, col+1, value)
                row += 1
        
    logger.info('Output sheet for each xaml file.')
    for wf in wfList:
        row = 0
        col = 0
        sheetName = sheetname_dict[wf.xamlFile]
        # Write the headline
        worksheet = workbook.add_worksheet(sheetName)
        worksheet.set_column(0, 0, 5)
        worksheet.set_column(1, 5, 15)
        worksheet.set_column(6, 6, 20)
        worksheet.set_row(0, 25)

        worksheet.write(row, col, wf.xamlFile, headlineFormat)
        row += 2
        col += 1
        
        worksheet.write(row, col, "Structure", chapterFormat)
        row += 2
        
        
        # Output structure
        for act in wf.allActs:
            worksheet.write(row, col, act.layer)
            if act.is_unused:
                worksheet.write(row, col+1, str(act), ignoreFormat)
                row +=1
                continue
            
            if act.name == "Flowchart" and act.layer > 0:
                worksheet.write(row, col+1, str(act), shouldFormat)
            elif act.name == "CommentOut":
                worksheet.write(row, col+1, str(act), ignoreFormat)
            elif act.name in ["If","While", "DoWhile"]: 
                worksheet.write(row, col+1, str(act))
                worksheet.write(row, col+6, act.condition)                
            elif act.name == "Sequence" and not act.hasChildActs:
                worksheet.write(row, col+1, str(act), shouldFormat)
            elif act.name == "LogMessage":
                worksheet.write(row, col+1, str(act), doubleCheckFormat)
                worksheet.write(row, col+6, act.logLevel + "," + act.logMessage)
            elif act.name in ["Parallel", "Delay", "TryCatch.Catches"]:
                worksheet.write(row, col+1, str(act), doubleCheckFormat)
            elif act.name == "Assign":
                worksheet.write(row, col+1, str(act))
                worksheet.write(row, col+6, act.assignTo + " = " +act.assignValue)
            elif act.name == "GetRobotAsset":
                worksheet.write(row, col+1, str(act), doubleCheckFormat)
                worksheet.write(row, col+6, act.assetName)
            elif act.name == "InvokeWorkflowFile":
                worksheet.write(row, col+1, str(act))
                worksheet.write(row, col+6, act.workflowFileName)                
            else:
                worksheet.write(row, col+1, str(act))
            if act.hasStrAttrib:
                worksheet.write_comment(row, col+1, act.strAttrib, {'x_scale': 2, 'y_scale':2})
            row +=1
        
        row += 1
        
        
        worksheet.write(row, col, "Activity Stat", chapterFormat)
        row += 2
        col += 1
        
        worksheet.write(row, col, "Activity", tableHeaderFormat)
        worksheet.write(row, col+1, "Count", tableHeaderFormat)
        
        row += 1
        
        for key, value in wf.counter.items():
            worksheet.write(row, col, key, tableFormat)
            worksheet.write(row, col+1, value, tableFormat)
            row += 1
        
        row += 1

        worksheet.write(row, col, "Log Level", tableHeaderFormat)
        worksheet.write(row, col+1, "Count", tableHeaderFormat)
        
        row += 1
        
        for key, value in wf.logCounter.items():
            worksheet.write(row, col, key, tableFormat)
            worksheet.write(row, col+1, value, tableFormat)
            row += 1
        
        row += 1
        col -= 1
        
        # Argument List
        worksheet.write(row, col, "Argument List", chapterFormat)
        row += 2
        col += 1
        fixedCol = col
        
        worksheet.write(row, col, "Name", tableHeaderFormat)
        worksheet.write(row, col + 1, "Direction", tableHeaderFormat)
        worksheet.write(row, col + 2, "Argument type", tableHeaderFormat)
        worksheet.write(row, col + 3, "Default value", tableHeaderFormat)
        
        row += 1
        
        for argName, argUnit in wf.argDict.items():
            worksheet.write(row, col, argName, tableFormat)
            for key, value in argUnit.items():
                if key in ["Direction", "Type", "Default"]:
                    worksheet.write(row, col+1, value, tableFormat)
                elif key in ["checkName", "checkFilePath"]:
                    worksheet.write(row, col+1, value)
                col += 1
            col = fixedCol
            row += 1
        
        row += 1
        col -= 1
        
        # Variable List
        worksheet.write(row, col, "Variable List", chapterFormat)
        row += 2
        col += 1
        fixedCol = col
        
        worksheet.write(row, col, "Name", tableHeaderFormat)
        worksheet.write(row, col + 1, "Variable type", tableHeaderFormat)
        worksheet.write(row, col + 2, "Default", tableHeaderFormat)
        
        row += 1
        for varName, varUnit in wf.varDict.items():
            worksheet.write(row, col, varName, tableFormat)
            for key, value in varUnit.items():
                if key in ["Type", "Default"]:
                    worksheet.write(row, col+1, value, tableFormat)
                elif key in ["checkName", "checkFilePath"] and key in checkitems:
                    worksheet.write(row, col+1, value)
                col += 1
            col = fixedCol
            row += 1
        
        row += 1            
        col -= 1
        
        # Overall Check Points
        worksheet.write(row, col, "Overall Check Points", chapterFormat)
        row += 2
        col += 1               
        
        for item, res in wf.check_result.items():
            worksheet.write(row, col, item)
            worksheet.write(row, col+1, res, check_resultFormat)
            row += 1
            
        row += 1
        col -= 1
        
        worksheet.write(row, col, "Activities Check Points", chapterFormat)
        row += 2
        col += 2

        for act in wf.allActs:
            col -= 1
            worksheet.write(row, col-1, "index")   
            worksheet.write(row, col, str(act)) 
            row += 1
            col += 1
            
            for item, res in act.check_result.items():
                if item in checkitems:
                    worksheet.write(row, col-2, "item")
                    worksheet.write(row, col-1, str(act), grayFontFormat)
                    worksheet.write(row, col, item, shouldFormat)
                    worksheet.write(row, col+1, res)
                    row += 1
        
    workbook.close()
    
    # Generate issue list
    logger.info('Creating IssueList.')
    workbook = xlsxwriter.Workbook(cwd + pj.projectFolder + "/IssueList_" + version + "_" +
                                   pj.projectFolder + "_" + str(datetime.date.today()) + ".xlsx")
    
    tableHeaderFormat = workbook.add_format()
    tableHeaderFormat.set_bold()
    tableHeaderFormat.set_border()
    
    tableFormat = workbook.add_format()
    tableFormat.set_border()
    logger.info('Output Issue List sheet.')
    issuelist_sheet = workbook.add_worksheet("Issue List")
    row = 0
    col = 0
    issuelist_sheet.set_column(0, 2, 20)
    issuelist_sheet.set_column(3, 4, 10)
    issuelist_sheet.set_column(5, 6, 20)
    issuelist_sheet.set_column(7, 7, 40)
    issuelist_sheet.write(row, col,   "Xaml File Path", tableHeaderFormat)
    issuelist_sheet.write(row, col + 1, "Internal Path", tableHeaderFormat)
    issuelist_sheet.write(row, col + 2, "Index", tableHeaderFormat)
    issuelist_sheet.write(row, col + 3, "Item", tableHeaderFormat)
    issuelist_sheet.write(row, col + 4, "Level", tableHeaderFormat)
    issuelist_sheet.write(row, col + 5, "Current Value", tableHeaderFormat)
    issuelist_sheet.write(row, col + 6, "Issue", tableHeaderFormat)
    issuelist_sheet.write(row, col + 7, "Explanation", tableHeaderFormat)
    issuelist_sheet.write(row, col + 8, "Example", tableHeaderFormat)

    
    row += 1
    for record_id, record in pj.project_result_dict.items():
        checkItem = record["issue"]
        if checkItem in skipCheckItems:
            continue
        if checkItem in checkitems:
            issuelist_sheet.write(row, col, record["xamlFile"], tableFormat)
            issuelist_sheet.write(row, col + 1, record["internal"], tableFormat)
            issuelist_sheet.write(row, col + 2, record["index"], tableFormat)
            issuelist_sheet.write(row, col + 3, record["item"], tableFormat)
            issuelist_sheet.write(row, col + 4, record["level"], tableFormat)
            issuelist_sheet.write(row, col + 5, record["value"], tableFormat)
            issuelist_sheet.write(row, col + 6, record["issue"], tableFormat)
            issuelist_sheet.write(row, col + 7, record["explanation"],tableFormat)
            issuelist_sheet.write(row, col + 8, record["xamlFile"] + ":\n" + record["internal"],tableFormat)
            row += 1

    logger.info('Output Argument / Variable List sheet.')
    argumentSheet = workbook.add_worksheet("Argument List")
    variableSheet = workbook.add_worksheet("Variable List")
    argumentSheet.set_column(0, 7, 20)
    variableSheet.set_column(0, 6, 20)
    row = 0
    col = 0
    
    argumentSheet.write(row, col    , "Xaml File Paht", tableHeaderFormat)
    argumentSheet.write(row, col + 1, "Internal Path",  tableHeaderFormat)
    argumentSheet.write(row, col + 2, "index",          tableHeaderFormat)
    argumentSheet.write(row, col + 3, "Argument Name",  tableHeaderFormat)
    argumentSheet.write(row, col + 4, "Direction",      tableHeaderFormat)
    argumentSheet.write(row, col + 5, "Argument type",  tableHeaderFormat)
    argumentSheet.write(row, col + 6, "Default value",  tableHeaderFormat)
    argumentSheet.write(row, col + 7, "Annotation",  tableHeaderFormat)

    variableSheet.write(row, col    , "Xaml File Paht", tableHeaderFormat)
    variableSheet.write(row, col + 1, "Internal Path",  tableHeaderFormat)
    variableSheet.write(row, col + 2, "index",          tableHeaderFormat)
    variableSheet.write(row, col + 3, "Variable name",  tableHeaderFormat)
    variableSheet.write(row, col + 4, "Variable type",  tableHeaderFormat)
    variableSheet.write(row, col + 5, "Default",        tableHeaderFormat)
    variableSheet.write(row, col + 6, "Annotation",  tableHeaderFormat)
    row +=1
    
    for wf in pj.wfList:
        col = 0
        for argName, argUnit in wf.argDict.items():
            argumentSheet.write(row, col, wf.xamlFile, tableFormat)
            act = argUnit["Activity"]
            argumentSheet.write(row, col + 1, act.getInternalPath(), tableFormat)
            argumentSheet.write(row, col + 2, act.index, tableFormat)
            argumentSheet.write(row, col + 3, argName, tableFormat)
            col += 3
            for key, value in argUnit.items():
                if key in ["Direction", "Type", "Default", "Annotation"]:
                    argumentSheet.write(row, col+1, value, tableFormat)
                    col += 1
            col = 0
            row += 1
    
    row = 1
    for wf in pj.wfList:
        col = 0
        for varName, varUnit in wf.varDict.items():
            variableSheet.write(row, col    , wf.xamlFile, tableFormat)
            act = varUnit["Activity"]
            variableSheet.write(row, col + 1, act.getInternalPath(), tableFormat)
            variableSheet.write(row, col + 2, act.index, tableFormat)
            variableSheet.write(row, col + 3, varName, tableFormat)
            col += 3
            for key, value in varUnit.items():
                if key in ["Type", "Default", "Annotation"]:
                    variableSheet.write(row, col+1, value, tableFormat)
                    col += 1
            col = 0
            row += 1        
    workbook.close()
    
def cleanUpSheetName(name):
    name = name.replace('.xaml', '')
    pattern = r"\/|\\|\*|\[|\]|\:|\?"
    name = re.sub(pattern, "_", name)
    if len(name) > 10:
        name = name[:5]+'-'+name[-4:]
    name = name.lower()
    return name
