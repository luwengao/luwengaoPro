import json
import os

check_items = json.load(open("config/internalCheckItems.json"))
check_acts = json.load(open("config/internalCheckActs.json"))
act_details = json.load(open("config/internalActDetails.json"))
act_to_package = json.load(open("config/activityToPackage.json"))


def write_project_stat(workbook, project, row=0, col=0):

    header_fmt = get_header_fmt(workbook)
    cell_fmt = get_cell_fmt(workbook)

    stat_sheet = workbook.add_worksheet("Overview")

    stat_sheet.write(row, col, "Activity", header_fmt)
    stat_sheet.write(row, col + 1, "Count", header_fmt)
    stat_sheet.write(row, col + 2, "Number of Workflow Used", header_fmt)
    stat_sheet.write(row, col + 3, "Package", header_fmt)
    row += 1

    for key, value in project.counter.items():
        stat_sheet.write(row, col, key, cell_fmt)
        stat_sheet.write(row, col + 1, value, cell_fmt)
        stat_sheet.write(row, col + 2, project.workflowCounter[key], cell_fmt)
        stat_sheet.write(
            row, col + 3, act_to_package[key] if key in act_to_package else "Custom", cell_fmt)
        row += 1
    # Output total count
    stat_sheet.write(row, col, "Total", header_fmt)
    stat_sheet.write(row, col + 1, sum(project.counter.values()), header_fmt)
    stat_sheet.write(row, col + 2, len(project.wfList), header_fmt)
    stat_sheet.write(row, col + 3, "", header_fmt)


def write_project_package_stat(workbook, project, row=0, col=0):
    header_fmt = get_header_fmt(workbook)
    cell_fmt = get_cell_fmt(workbook)
    stat_sheet = workbook.add_worksheet("Package Stats")

    stat_sheet.write(row,     col, "Full Path", header_fmt)
    stat_sheet.write(row + 1, col, "", header_fmt)
    stat_sheet.write(row,     col + 1, "Name", header_fmt)
    stat_sheet.write(row + 1, col + 1, "", header_fmt)
    col += 2

    column_index = dict()
    # column index
    for key, value in act_to_package.items():
        column_index[key] = col
        stat_sheet.write(row, col, key, header_fmt)
        stat_sheet.write(row + 1, col, value, header_fmt)
        col += 1
    row += 2
    col = 0
    for workflow in project.wfList:
        stat_sheet.write(row, col, workflow.xamlFile, header_fmt)
        stat_sheet.write(
            row, col + 1, os.path.basename(workflow.xamlFile), header_fmt)
        for key, value in workflow.counter.items():
            if key in column_index:
                stat_sheet.write(row, column_index[key], value, cell_fmt)
        row += 1


def get_header_fmt(workbook):
    return workbook.add_format({
        'bold': True,
        'border': True
    })


def get_cell_fmt(workbook):
    return workbook.add_format({
        'border': True
    })


def write_issue_list(workbook, project, row=0, col=0):
    header_fmt = get_header_fmt(workbook)
    cell_fmt = get_cell_fmt(workbook)
    issuelist_sheet = workbook.add_worksheet("Issue List")
    issuelist_sheet.set_column(0, 2, 20)
    issuelist_sheet.set_column(3, 4, 10)
    issuelist_sheet.set_column(5, 6, 20)
    issuelist_sheet.set_column(7, 7, 40)
    issuelist_sheet.write(row, col,   "Xaml File Path", header_fmt)
    issuelist_sheet.write(row, col + 1, "Internal Path", header_fmt)
    issuelist_sheet.write(row, col + 2, "Index", header_fmt)
    issuelist_sheet.write(row, col + 3, "Item", header_fmt)
    issuelist_sheet.write(row, col + 4, "Level", header_fmt)
    issuelist_sheet.write(row, col + 5, "Current Value", header_fmt)
    issuelist_sheet.write(row, col + 6, "Issue", header_fmt)
    issuelist_sheet.write(row, col + 7, "Explanation", header_fmt)
    issuelist_sheet.write(row, col + 8, "Example", header_fmt)
    row += 1
    for record in project.project_result_dict.values():
        check_item = record["issue"]
        if check_item in check_items:
            issuelist_sheet.write(row, col, record["xamlFile"], cell_fmt)
            issuelist_sheet.write(row, col + 1, record["internal"], cell_fmt)
            issuelist_sheet.write(row, col + 2, record["index"], cell_fmt)
            issuelist_sheet.write(row, col + 3, record["item"], cell_fmt)
            issuelist_sheet.write(row, col + 4, record["level"], cell_fmt)
            issuelist_sheet.write(row, col + 5, record["value"], cell_fmt)
            issuelist_sheet.write(row, col + 6, record["issue"], cell_fmt)
            issuelist_sheet.write(
                row, col + 7, record["explanation"], cell_fmt)
            issuelist_sheet.write(
                row, col + 8, record["xamlFile"] + ":\n" + record["internal"], cell_fmt)
            row += 1


def write_activities_details(workbook, project, row=0, col=0):
    header_fmt = get_header_fmt(workbook)
    cell_fmt = get_cell_fmt(workbook)

    for check_act in check_acts:
        act_details_sheet = workbook.add_worksheet(check_act)
        row = 0
        act_details_sheet.set_column(0, 1, 20)
        act_details_sheet.set_column(2, 2 + len(act_details), 10)
        act_details_sheet.write(row, col,   "Xaml File Path", header_fmt)
        act_details_sheet.write(row, col + 1, "Internal Path", header_fmt)

        index = col + 2
        for property in act_details:
            act_details_sheet.write(row, index, property, header_fmt)
            index = index + 1

        row = row + 1
        for workflow in project.wfList:
            for act in workflow.allActs:
                if act.name == check_act:
                    act_details_sheet.write(
                        row, col,     workflow.xamlFile, cell_fmt)
                    act_details_sheet.write(
                        row, col + 1, act.getInternalPath(), cell_fmt)
                    index = col + 2
                    for property in act_details:
                        if property in act.properties.keys():
                            act_details_sheet.write(
                                row, index, act.properties[property], cell_fmt)
                        else:
                            act_details_sheet.write(row, index, "", cell_fmt)
                        index = index + 1
                    row = row + 1


def write_activities_details_gui(workbook, project, check_act_list, check_prop_list, row=0, col=0):
    header_fmt = get_header_fmt(workbook)
    cell_fmt = get_cell_fmt(workbook)

    for check_act in check_act_list:
        act_details_sheet = workbook.add_worksheet(check_act)
        row = 0
        act_details_sheet.set_column(0, 1, 20)
        act_details_sheet.set_column(2, 2 + len(act_details), 10)
        act_details_sheet.write(row, col,   "Xaml File Path", header_fmt)
        act_details_sheet.write(row, col + 1, "Internal Path", header_fmt)

        index = col + 2
        for property in check_prop_list:
            act_details_sheet.write(row, index, property, header_fmt)
            index = index + 1

        row = row + 1
        for workflow in project.wfList:
            for act in workflow.allActs:
                if act.name == check_act:
                    act_details_sheet.write(
                        row, col,     workflow.xamlFile, cell_fmt)
                    act_details_sheet.write(
                        row, col + 1, act.getInternalPath(), cell_fmt)
                    index = col + 2
                    for property in check_prop_list:
                        act_details_sheet.write(
                            row,
                            index,
                            act.properties.get(property, ''),
                            cell_fmt)
                        index = index + 1
                    row = row + 1
