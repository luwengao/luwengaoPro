'''
Created on Nov 25, 2017

@author: Frank She
'''

import datetime
import json
import logging
import os
import shutil

from lib.draw_flowchart_funcs import draw_flowchart
from lib.init_funcs import extractXamlFiles, startCheck
from lib.write_checklist_funcs import writeChecklist
from lib.write_xlsx_funcs import writeResultAsXlsx

# Get execute path
exec_path = os.getcwd()

if not os.path.exists('report'):
    os.mkdir('report')
if not os.path.exists('log'):
    os.mkdir('log')


log_fmt = '%(asctime)s %(levelname)s:%(message)s'

log_file = exec_path + '/log/' + str(datetime.date.today()) + '.log'

logging.basicConfig(
    format=log_fmt,
    datefmt='%m-%d %H:%M',
    level=logging.DEBUG,
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler()
    ])

logger = logging.getLogger(__name__)

settings = json.load(open("config/settings.json"))
outputChecklist = settings["outputChecklist"]
VERSION = settings['Version']

logger.info("Code Analyzer " + VERSION)

logger.info("Code Analyzer " + VERSION)
logger.info("Let me know if any questions.")
logger.info("Email: frank.she@uipath.com")
logger.info(
    "Please be noted that the check result can only be used for reference.")


report_path = exec_path + "/report/"


# PROJECT_FOLDER = "D:/workspace/uipath/troubleshooting"
PROJECT_FOLDER = "/home/fshe/Downloads/HpiCode/GDL_CA_Brz_Brazil_SpecialCustomers_SAPtoQueue"
# PROJECT_FOLDER = '/home/fshe/Downloads/HpiCode/GDL_CA_Brz_Brasil_MailStatements'
# PROJECT_FOLDER = '/home/fshe/Downloads/HpiCode/test_sheetnames'

PROJECT_FILE_DICT = extractXamlFiles(PROJECT_FOLDER)
PROJECT = startCheck(PROJECT_FILE_DICT, PROJECT_FOLDER)
output_folder = report_path + PROJECT.projectFolder
if os.path.exists(output_folder):
    shutil.rmtree(output_folder)
os.mkdir(output_folder)
writeResultAsXlsx(PROJECT, report_path, VERSION)

# if outputChecklist == 'True' :
#     writeChecklist(PROJECT, exePath, settings["robotFolder"])

draw_flowchart(PROJECT, report_path, VERSION)
