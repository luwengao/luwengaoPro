'''
Created on Oct 29, 2017

@author: fshe
'''
import json
import os
import re
from collections import Counter, OrderedDict

from UiObject.Act import Act

ISSUE_LEVEL_DICT = json.load(open("config/issueLevel.json"))

class Project(object):
    '''
    classdocs
    '''
    # Check Benchmark
    checkBmk = json.load(open("config/projectCheckBenchmark.json"))

    def __init__(self, wfList, strProjectFolder, projectFilesDict):
        '''
        Constructor
        '''
        # Activity stats of the whole project
        self.counter = Counter()
        # Number of workflow each activity used of the whole project
        self.workflowCounter = Counter()
        self.logCounter = Counter()
        self.wfList = wfList
        self.projectFolder = os.path.basename(strProjectFolder)
        self.projectFilesDict = projectFilesDict
        self.check_result = dict()
        self.countActAndWorkflow()
        self.countLog()
        
        # Invoke workflow dictionary: name -> invoked workflow
        self.invoked_wf_dict = dict()
        # Workflow dictionary: name -> workflow
        self.wf_dict = dict()

        self.main_wf = None

        # Call Methods
        # Build invoke workflow dictionary
        # Workflow:String -> invoke workflows:list
        # Workflow:String -> workflow: Workflow
        self.build_dict()
        self.checkProjectFiles()
        self.checkFilename()
        self.checkGetCredential()
        self.checkTerminateWorkflow()
        self.project_result_dict = dict()
        # Output excel based on this dictionary
        self.generate_project_result_dict()
        
    def countActAndWorkflow(self):
        '''
        Counts the number of activities and workflows in the project.
        '''
        for wf in self.wfList:
            self.counter += wf.counter
            self.workflowCounter += wf.workflowCounter
        self.counter = OrderedDict(self.counter.most_common())
        self.workflowCounter = OrderedDict(self.workflowCounter.most_common())

    def countLog(self):
        '''
        Counts the number of log messages in the project.
        '''
        for wf in self.wfList:
            self.logCounter += wf.logCounter
        self.logCounter = OrderedDict(sorted(self.logCounter.items()))    
    
    def checkProjectFiles(self):
        '''
        Makes the following checks about the project: whether project.json exists, whether the path to the main file is hard coded and whether Main.xaml exists.
        '''
        # Checks whether project.json exists
        if not self.projectFilesDict['project.json']:
            self.check_result['checkProjectJson'] = Act.commentDict['checkProjectJson']

        main_file = self.projectFilesDict['main']
        # Checks whether the path to the main file is hard coded.
        if re.fullmatch(r'[A-Za-z]:(\\|¥).*', main_file):
            self.check_result["checkHardcodedMainFile"] = Act.commentDict['checkHardcodedMainFile'].format(main_file)

        if main_file in self.wf_dict.keys():
            self.main_wf = self.wf_dict[main_file]

        main_file = os.path.basename(main_file)
        # Checks whether Main.xaml exists.
        if main_file != 'Main.xaml' or not os.path.isfile(main_file):
            self.check_result["checkMainFile"] = Act.commentDict["checkMainFile"]
    
    def checkFilename(self):
        """
        Checks whether the workflow file name follows a specific pattern.
        """
        # pattern = r"(?:[A-Z][a-z0-9]+)*[A-Z]([A-Z]+|[a-z0-9]+)(_[0-9]+)?\.xaml"
        re_prefix = r"([0-9]{2}(_[0-9]{2})*(\.|_))?"
        re_title_case = r"([A-Z][A-Za-z0-9]+)(?:(_| )[A-Z][A-Za-z0-9]+)*"
        re_postfix = r"(_[0-9]{8})?\.xaml"
        pattern = re_prefix + re_title_case + re_postfix
        for wf in self.wfList:
            if wf.isCommon:
                filename = os.path.basename(wf.xamlFile)
                if not filename.startswith(Project.checkBmk["commonFileNamePattern"]):
                    wf.check_result["checkCommonWorkflowPrefix"] = Act.commentDict["checkCommonWorkflowPrefix"].format(filename, Project.checkBmk["commonFileNamePattern"])
                    if not re.fullmatch(r"[A-Za-z0-9_ .]+", filename) is None:
                        if re.fullmatch(pattern, filename) is None:
                            wf.check_result["checkWorkflowName"] = Act.commentDict["checkWorkflowName"].format(filename)
                else:
                    if not re.fullmatch(r"[A-Za-z0-9_ .]+", filename) is None:
                        cwfPattern = re.escape(Project.checkBmk["commonFileNamePattern"])+pattern
                        if re.fullmatch(cwfPattern, filename) is None:
                            wf.check_result["checkWorkflowName"] = Act.commentDict["checkWorkflowName"].format(filename)                        
            else:
                filename = wf.xamlFile
                if not re.fullmatch(r"[A-Za-z0-9_ .]+", filename) is None:
                    if re.fullmatch(pattern, filename) is None:
                        wf.check_result["checkWorkflowName"] = Act.commentDict["checkWorkflowName"].format(filename)


    def checkGetCredential(self):
        '''
        Checks whether Get Credential is being used in the project.
        '''
        if not "GetRobotCredential" in self.counter.keys():
            self.check_result["checkGetCredential"] = Act.commentDict["checkGetCredential"]
    
    def build_dict(self):
        invoked_wf_dict = dict()
        wf_dict = dict()
        for wf in self.wfList:
            invoked_wf_dict[wf.xamlFile] = wf.invokedWfList
            wf_dict[wf.xamlFile] = wf
        self.invoked_wf_dict = invoked_wf_dict
        self.wf_dict = wf_dict
    
    def checkTerminateWorkflow(self):
        '''
        Checks whether Terminate Workflow is used in the project.
        '''
        for wf in self.wfList:
            if wf.isCommon:
                if "TerminateWorkflow" in wf.counter.keys():
                    wf.check_result["checkTerminateWorkflow"] = Act.commentDict["checkTerminateWorkflow"]

    def generate_project_result_dict(self):
        """
        Generate project result as a dictionary
        {
            recordId: {
                xamlFile, 
                internalPath, 
                index, 
                item, 
                level, 
                value, 
                issue, 
                explanation
                }
        }
        """
        record_id = 0
        project_result_dict = dict()
        for key, value in self.check_result.items():
            record = generate_record_dict(
                "", "", "", "Project", ISSUE_LEVEL_DICT[key], "", key, value)
            project_result_dict[record_id] = record
            record_id += 1
        for workflow in self.wfList:
            for key, value in workflow.check_result.items():
                record = generate_record_dict(workflow.xamlFile, "", "", "Workflow", ISSUE_LEVEL_DICT[key], "", key, value)
                project_result_dict[record_id] = record
                record_id += 1
            for act in workflow.allActs:
                for act_key, act_value in act.check_result.items():
                    value = None
                    if act_key in ["checkDelay", "checkDelayWithAnnotation"]:
                        value = act.delay
                    elif "Delay" in act_key:
                        delay_type = act_key.replace("check", "")
                        delay_type = delay_type.replace("WithAnnotation", "")
                        value = act.delayDict[delay_type]
                    elif act_key == "checkDisplayName":
                        value = act.displayName
                    else:
                        value = act.name                        
                    record = generate_record_dict(
                        workflow.xamlFile, act.getInternalPath(), act.index, "Activity", ISSUE_LEVEL_DICT[act_key], value, act_key, act_value)
                    project_result_dict[record_id] = record
                    record_id += 1
            for arg_name, arg_unit in workflow.argDict.items():
                for checkItem in ["checkName", "checkFilePath", "checkHardcodedPassword"]:
                    if checkItem in arg_unit.keys():
                        record = generate_record_dict(
                            workflow.xamlFile, 
                            arg_unit["Activity"].getInternalPath(), 
                            arg_unit["Activity"].index, 
                            "Argument", 
                            ISSUE_LEVEL_DICT[checkItem], 
                            arg_name, 
                            checkItem, 
                            arg_unit[checkItem])
                        project_result_dict[record_id] = record
                        record_id += 1
            for var_name, var_unit in workflow.varDict.items():
                for checkItem in ["checkName", "checkFilePath", "checkHardcodedPassword", "checkUnusedVar"]:
                    if checkItem in var_unit.keys():
                        record = generate_record_dict(
                            workflow.xamlFile,
                            var_unit["Activity"].getInternalPath(),
                            var_unit["Activity"].index,
                            "Variable",
                            ISSUE_LEVEL_DICT[checkItem],
                            var_name,
                            checkItem,
                            var_unit[checkItem])
                        project_result_dict[record_id] = record
                        record_id += 1
        self.project_result_dict = project_result_dict

def generate_record_dict(xamlFile, internalPath, index, item, level, value, issue, explanation):
    record_dict = dict()
    record_dict["xamlFile"] = xamlFile
    record_dict["internal"] = internalPath
    record_dict["index"] = index
    record_dict["item"] = item
    record_dict["level"] = level
    record_dict["value"] = value
    record_dict["issue"] = issue
    record_dict["explanation"] = explanation
    return record_dict
