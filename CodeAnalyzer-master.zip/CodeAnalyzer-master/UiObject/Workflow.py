'''
Created on Oct 28, 2017

@author: Frank She
'''

import os
import re
from collections import Counter, OrderedDict

from UiObject.Act import Act, checkLogMessageInSequece, getFullList, getSubActs, extract_1st_layer_in_flowchart, checkLogMessageInTry, checkLogMessageInFlowchart


class Workflow(object):
    '''
    classdocs
    '''


    def __init__(self, rootAct, xamlstr, xamlFile, xamlType):
        '''
        Constructor
        '''
        # List of all activity in the workflow
        self.allActs = getFullList(rootAct)
        self.rootAct = rootAct
        # Dictionary of all variables in all activities
        self.varDict = dict()
        # Dictionary of all arguments in all acitvities
        self.argDict = dict()
        # Xaml file string, to decide if variable is used
        self.xamlstr = xamlstr
        # Dictionary to store check result of workflow
        self.check_result = dict()
        # Activity counter dictionary to display activities stats
        self.counter = Counter()
        # Number of workflow each activity used
        self.workflowCounter = Counter()
        # Xaml File Name
        self.xamlFile = xamlFile
        # Xaml File Type, main, common or others
        self.xamlType = xamlType
        self.isCommon = False
        self.isMain = False
        # Store invoked workflow lists
        self.invokedWfList = list()
        self.extractInvokedWfList()
        self.logCounter = Counter()
        self.totalDelay = 0.0
        self.checkTotalDelay()
        
        # Decide Xaml File Type
        if xamlType == "common":
            self.isCommon = True
        elif xamlType == 'main':
            self.isMain = True
            self.checkMainFlowchart()
            self.checkTopFlowchart()
        
        self.checkTopLayerIsFlowchart()
        self.extractVarDict()
        self.extractArgDict()
        self.checkUnusedVar()
        # self.checkNestedIf()
        self.countAct()
        self.countWorkflow()
        self.checkCatch()
        self.checkTerminateWorkflow()
        self.checkLogMessage()
        self.checkFilePath()
        self.countLog()
        # checkActCountInFlowchart
        # checkActNotInCatch
        self.checkSendHotkey()
        self.checkActsWithSameSelector()
        self.checkWorkflowStartLog()
        self.checkWorkflowEndLog()
        self.checkNestedSequence()
        self.checkCitrix()
        self.checkArgsInMain()
        self.checkHardcodedPassword()
        self.checkAnnotation()

    def checkAnnotation(self):
        '''
        Checks whether the top activity of the workflow has annotations.
        '''
        if not self.rootAct.hasAnnotation:
            self.rootAct.check_result["checkAnnotation"] = Act.commentDict["checkAnnotation"]
        
    def extractVarDict(self):
        varDict = dict()
        for act in self.allActs:
            if act.hasVarDict:
                varDict.update(act.varDict)
        self.varDict = varDict
        
    def extractArgDict(self):
        argDict = dict()
        for act in self.allActs:
            if act.hasArgDict:
                argDict.update(act.argDict)
        self.argDict = argDict
        
    def checkNestedIf(self):
        '''
        Checks whether there are nested If activities.
        '''
        for act in getSubActs(self.rootAct):
            if act.name == "If":
                # Nested Leve1
                for childAct in getSubActs(act):
                    if childAct.name == "If":
                        #Nested Level 2
                        for grandchild in getSubActs(childAct):
                            if grandchild.name == "If":
                                act.check_result["checkNestedIf"] += '{0}, {1}, {2} are nested Ifs\n'.format(
                                    act, childAct, grandchild)
    
    def checkUnusedVar(self):
        '''
        Checks whether there are unused variables in the workflow.
        '''
        for act in self.allActs:
            if act.hasVarDict:
                for name in act.varDict.keys():
                    pattern = r"\[.*" + re.escape(name) + r".*\]"
                    if re.search(pattern, self.xamlstr) is None:
                        act.check_result["checkUnusedVar"] = Act.commentDict["checkUnusedVar"].format(name)
    
    def countAct(self):
        '''
        Count the number of occurrences of each activity in the workflow.
        '''
        counter = Counter()
        for act in self.allActs:
            if act.name.count('.') == 1:
                continue
            counter[act.name] += 1
        self.counter = OrderedDict(counter.most_common())
    
    def countWorkflow(self):
        '''
        Count the number of activities in the workflow.
        '''
        self.workflowCounter = Counter(self.counter.keys())

    def countLog(self):
        '''
        Count the number of occurrences of each log level in the workflow.
        '''
        counter = Counter()
        for act in self.allActs:
            if act.name == "LogMessage":
                counter[act.logLevel] += 1
        self.logCounter = OrderedDict(sorted(counter.items()))
    
    def checkCatch(self):
        '''
        Checks the following points about the Catch block: whether it is empty, whether there are workflows invoked, whether there is a throw/rethrow associated with a error log. In addition, warns about the usage of too many activities in the Catch block.
        '''
        for act in self.allActs:
            hasRelatedActs = False
            logLevel = None
            hasThrow = False
            if act.name == "TryCatch.Catches":
                # Checks whether the Catch block is empty
                if not act.hasChildActs:
                    act.check_result["checkIfEmptyCatch"] = Act.commentDict["checkIfEmptyCatch"]
                    continue
                for sub in getSubActs(act):
                    if sub.name == "LogMessage":
                        logLevel = sub.logLevel
                        hasRelatedActs = True
                    if sub.name in ["Throw", "Rethrow", "TerminateWorkflow"]:
                        hasThrow = True
                    if sub.name in ["InvokeWorkflowFile"]:
                        hasRelatedActs = True
                # Checks whether there are workflows invoked from the Catch block
                if not hasRelatedActs:
                    act.check_result["checkNoRelatedActInCatch"] = Act.commentDict["checkNoRelatedActInCatch"]
                else:
                    if not logLevel is None:
                        # Checks whether there is a throw/rethrow associated with a error log inside the Catch block
                        if logLevel == "Error" and not hasThrow:
                            act.check_result["checkErrorLogWithoutThrow"] = Act.commentDict["checkErrorLogWithoutThrow"]
                    # Checks whether too many activities are used in the Catch block
                    if len(getSubActs(act)) > 10:
                        act.check_result["checkCatchDetail"] = Act.commentDict["checkCatchDetail"]
                    else:
                        detail = ""
                        for sub in (getSubActs(act)):
                            if sub.name == "LogMessage":
                                detail += "Log: {0}, {1} \n".format(sub.logLevel, sub.logMessage)
                            elif sub.name == "Assign":
                                detail += "Assign: {0} = {1} \n".format(sub.assignTo, sub.assignValue)
                            elif sub.name == "InvokeWorkflowFile":
                                detail += "InvokeWorkflowFile: {0}\n".format(sub.workflowFileName)
                            elif sub.name == "Throw":
                                if "Exception" in sub.attrib.keys():
                                    detail += "Throw: {0}\n".format(sub.attrib["Exception"])
                            elif sub.name == "Rethrow":
                                detail += "Rethrow\n."
                            elif sub.name == "TerminateWorkflow":
                                detail += "TerminateWorkflow\n"
                        act.check_result["checkCatchDetail"] = detail

    def checkTerminateWorkflow(self):
        '''
        Checks whether Terminate Workflow is used.
        '''
        if not self.isMain and "TerminateWorkflow" in self.counter.keys():
            self.check_result["checkTerminateWorkflow"] = Act.commentDict["checkTerminateWorkflow"]

    def checkLogMessage(self):
        '''
        Checks whether log messages start with a defined prefix.
        '''
        if self.isCommon:
            logPrefix = os.path.splitext(os.path.basename(self.xamlFile))[0]
            isPredefined = False
            logheader = ""
            if 'LOGHEADER' in self.varDict:
                logheader = self.varDict['LOGHEADER']['Default']
                if logPrefix in logheader:
                    isPredefined = True
            for act in self.allActs:
                if act.name == "LogMessage":
                    if 'LOGHEADER' in act.logMessage:
                        if not isPredefined:
                            act.check_result["checkLogMessage"] = Act.commentDict["checkLogMessage"].format(
                                act.logMessage, logPrefix)
                    elif not logPrefix in act.logMessage:
                        act.check_result["checkLogMessage"] = Act.commentDict["checkLogMessage"].format(
                            act.logMessage, logPrefix)

    def extractInvokedWfList(self):
        '''
        Extracts the list of invoked workflows.
        '''
        wfList = list()
        for act in self.allActs:
            if act.name == "InvokeWorkflowFile":
                wfList.append(act.workflowFileName)
        self.invokedWfList = set(wfList)
    
    def checkFilePath(self):
        '''
        Checks whether there are hard-coded filepaths.
        '''
        for act in self.allActs:
            pattern = r"[A-Za-z]:(\\|¥).*"
            if act.hasFilePath and act.name != 'OpenApplication':
                if not re.search(pattern, act.filePath) is None:
                    act.check_result["checkFilePath"]= Act.commentDict["checkFilePath"].format(act.filePath)
            if act.name == "Assign" and not act.is_unused:
                assign = act.assignTo + " = " + act.assignValue
                if not re.search(pattern, assign) is None:
                    act.check_result["checkFilePath"]= Act.commentDict["checkFilePath"].format(assign)
            if act.hasArgDict:
                for argName, argUnit in act.argDict.items():
                    argDefault = argUnit["Default"]
                    if not re.search(pattern, argDefault) is None:
                        argUnit["checkFilePath"] = Act.commentDict["checkFilePath"].format(argDefault)
            if act.hasVarDict:
                for varName, varUnit in act.varDict.items():
                    varDefault = varUnit["Default"]
                    if not re.search(pattern, varDefault) is None:
                        varUnit["checkFilePath"] = Act.commentDict["checkFilePath"].format(varDefault)
    
    def checkTopFlowchart(self):
        '''
        Checks whether the first layer (top level) is a Try Catch activity.
        '''
        if self.rootAct.name == 'TryCatch':
            return
        elif self.rootAct.name == 'Flowchart':
            for act in extract_1st_layer_in_flowchart(self.rootAct):
                if act.name != 'TryCatch':
                    act.check_result["checkActNotInCatch"] = Act.commentDict["checkActNotInCatch"].format(str(act))
        else:
            for sub in self.rootAct.childActs:
                if sub.name != 'TryCatch':
                    sub.check_result["checkActNotInCatch"] = Act.commentDict["checkActNotInCatch"].format(str(sub))

    def checkMainFlowchart(self):
        '''
        Checks whether the main flowchart has too many activities.
        '''
        for act in self.allActs:
            if act.name == 'Flowchart':
                main_act_list = extract_1st_layer_in_flowchart(act)
                if len(main_act_list) < 3:
                    continue
                # Checks whether the flowchart has too many activities
                self.check_result["checkActCountInFlowchart"] = Act.commentDict["checkActCountInFlowchart"].format(
                    len(main_act_list))
                for l1_act in main_act_list:
                    if l1_act.name == "Sequence":
                        checkLogMessageInSequece(l1_act)
                    elif l1_act.name == 'TryCatch':
                        l1_act = checkLogMessageInTry(l1_act)
                        if l1_act is None:
                            continue
                    elif l1_act.name == 'Flowchart':
                        checkLogMessageInFlowchart(l1_act)
                        continue
                    
                    for l2_act in l1_act.childActs:
                        if l2_act.name == 'Sequence':
                            checkLogMessageInSequece(l2_act)
                        elif l2_act.name == 'TryCatch':
                            checkLogMessageInTry(l2_act)
                        elif l2_act.name == 'Flowchart':
                            checkLogMessageInFlowchart(l2_act)
                break
            elif act.name == 'Sequence':
                checkLogMessageInSequece(act)
                for l2_act in act.childActs:
                    if l2_act.name == 'Sequence':
                        checkLogMessageInSequece(l2_act)
                    elif l2_act.name == 'TryCatch':
                        checkLogMessageInTry(l2_act)
                    elif l2_act.name == 'Flowchart':
                        checkLogMessageInFlowchart(l2_act)

    def checkSendHotkey(self):
        '''
        Checks whether Send Hotkey Alt+F4 is being used or whether a Send Hotkey activity is used without a container and a selector.
        '''
        subList = list()
        for act in self.allActs:
            # Check Alt + F4
            if act.name == 'SendHotkey':
                if act.keyModifiers == 'Alt' and act.key == 'f4':
                    act.check_result['checkHotkeyAltF4'] = Act.commentDict['checkHotkeyAltF4']

            if act in subList:
                continue
            elif act.name in ["OpenBrowser", "OpenApplication", "BrowserScope", "WindowScope"]:
                subList = getSubActs(act)
            # Check whether a Send Hotkey activity is used without a selector
            elif act.name == "SendHotkey" and act.selector == "{Null}":
                if act.hasKeyModifiers:
                    if act.keyModifiers == "Win":
                        continue
                act.check_result["checkSendHotkey"] = Act.commentDict["checkSendHotkey"]
                
    def checkTopLayerIsFlowchart(self):
        '''
        Checks whether the top layer of the workflow is a flowchart.
        '''
        if self.isMain and not self.rootAct.name == "Flowchart":
            self.check_result["checkTopLayerIsFlowchart"] = Act.commentDict["checkTopLayerIsFlowchart"]
            
    def checkArgsInMain(self):
        '''
        Checks whether there are arguments used in the main workflow.
        '''
        if self.isMain and self.rootAct.hasArgDict:
            self.check_result["checkArgsInMain"] = Act.commentDict["checkArgsInMain"]
    
    def checkTotalDelay(self):
        '''
        Checks the total time used in delays in the workflow.
        '''
        totalDelay = 0.0
        for act in self.allActs:
            if act.name == "Delay":
                totalDelay += act.delay if not act.delay is None else 0
                continue
            elif act.hasDelayBefore:
                totalDelay += act.delayBefore
            elif act.hasDelayMS:
                totalDelay += act.delayMS
            elif act.hasDelayAfter:
                totalDelay += act.delayAfter
        self.totalDelay = totalDelay
        if self.totalDelay > 0:
            self.check_result["checkTotalDelay"] = Act.commentDict["checkTotalDelay"].format(self.totalDelay)

    def checkActsWithSameSelector(self):
        '''
        Checks whether multiple activities use the same selector.
        '''
        fromAct = None
        toAct = None
        for act in self.allActs:
            if act.hasSelector:
                if act.selector == "{Null}":
                    continue
                if fromAct is None:
                    fromAct = act
                else:
                    if fromAct.selector == act.selector and fromAct.layer == act.layer:
                        toAct = act
                    elif not toAct is None:
                        fromAct.check_result["checkActsWithSameSelector"] = Act.commentDict["checkActsWithSameSelector"].format(fromAct.index, toAct.index)
                        fromAct = None
                        toAct = None
                    else:
                        fromAct = None
        if not toAct is None:
            fromAct.check_result["checkActsWithSameSelector"] = Act.commentDict["checkActsWithSameSelector"].format(fromAct.index, toAct.index)
    
    def checkWorkflowStartLog(self):
        '''
        Checks whether there is a info log at the start of the workflow.
        '''
        for act in self.allActs:
            if act.name in ["Flowchart", "Flowchart.StartNode", "Sequence", "FlowDecision","FlowDecision.True"]:
                continue
            elif act.name != "LogMessage":
                self.check_result["checkWorkflowStartLog"] = Act.commentDict["checkWorkflowStartLog"].format(act.index)
                break
            else:
                break
                
    def checkWorkflowEndLog(self):
        '''
        Checks whether there is a info log at the end of the workflow.
        '''
        for act in reversed(self.allActs):
            if act.name in []:
                continue
            elif act.name != "LogMessage":
                self.check_result["checkWorkflowEndLog"] = Act.commentDict["checkWorkflowEndLog"].format(act.index)
                break
            else:
                break
    
    def checkNestedSequence(self):
        '''
        Checks whether there is only a sequence (no other activities) inside a sequence.
        '''
        for act in self.allActs:
            if act.name == "Sequence":
                if act.hasChildActs:
                    if len(act.childActs) == 1 and act.childActs[0].name == "Sequence":
                        act.check_result["checkNestedSequence"] = Act.commentDict["checkNestedSequence"].format(act.index)

    def checkCitrix(self):
        '''
        Checks whether Citrix related activities are used in other programs.
        '''
        skipList = list()
        for act in self.allActs:
            if act in skipList:
                continue
            elif act.name in ["WindowScope", "OpenApplication"]:
                if act.hasSelector:
                    isCitrix = False
                    for program in Act.citrixRelatedProgramList:
                        if program in act.selector:
                            isCitrix = True
                            break
                    if isCitrix:
                        skipList = getSubActs(act)
                        continue
            elif act.name in Act.citrixRelatedActList:
                if act.hasSelector:
                    isCitrix = False
                    for program in Act.citrixRelatedProgramList:
                        if program in act.selector:
                            isCitrix = True
                            break
                    if not isCitrix:
                        act.check_result["checkCitrix"] = Act.commentDict["checkCitrix"].format(str(act))
                else:
                    act.check_result["checkCitrix"] = Act.commentDict["checkCitrix"].format(str(act))

    def checkHardcodedPassword(self):
        '''
        Checks whether there are hardcoded password in the workflow.
        '''
        for argName, argUnit in self.argDict.items():
            if 'password' in argName or ('PASSWORD' in argName) or ('Password' in argName) or ('パスワード' in argName):
                if argUnit['Default'] == "":
                    continue
                elif argUnit['Default'].count('¥') > 0 or argUnit['Default'].count('\\') > 0:
                    continue
                argUnit["checkHardcodedPassword"] = Act.commentDict["checkHardcodedPassword"].format(
                    argUnit['Default'])
        for varName, varUnit in self.varDict.items():
            if 'password' in varName or ('PASSWORD' in varName) or ('Password' in varName) or ('パスワード' in varName):
                if varUnit['Default'] == "":
                    continue
                elif varUnit['Default'].count('¥') > 0 or varUnit['Default'].count('\\') > 0:
                    continue
                varUnit["checkHardcodedPassword"] = Act.commentDict["checkHardcodedPassword"].format(
                    varUnit['Default'])
