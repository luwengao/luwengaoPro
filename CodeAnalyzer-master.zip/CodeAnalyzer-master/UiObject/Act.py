'''
Created on Oct 24, 2017

@author: Frank She
'''

import json
import logging
import os
import re

logger = logging.getLogger(__name__)


class Act(object):
    '''
    classdocs
    '''
    actConfig = open("config/activityDisplayNameDict.json")
    actDict = json.loads(actConfig.read())
    actList = actDict.keys()
    nodeCheckList = json.load(open("config/sequenceNodeList.json"))
    lv1ActNodeList = json.load(open("config/lv1ActNode.json"))
    lv2ActNodeList = json.load(open("config/lv2ActNode.json"))
    typeDict = json.load(open("config/datatypeDict.json"))
    # Check Benchmark
    checkBmk = json.load(open("config/activityCheckBenchmark.json"))
    commentDict = json.load(open("config/checkComment.json"))
    citrixRelatedActList = json.load(open("config/citrixRelatedActs.json"))
    citrixRelatedProgramList = json.load(
        open("config/citrixRelatedPrograms.json"))
    uiActList = json.load(open("config/activitiesWithScreenshot.json"))
    screenshotFolder = ".screenshots/"
    inputProperties = list()

    def __init__(self, tag, attrib, index, parent_act, node, is_unused=False):
        '''
        -tag: Tag of the XML element that defines the activity
        -attrib: Dictionary having the XML element's attributes
        -index: Unique ID for each activity instance
        -parent_act: Parent activity (in case the current one is inside another)
        -node: 
        -is_unused: True if the activity is inside a comment block
        '''
        # Activity attributes
        # Store all properties for investigation
        self.properties = dict()
        # The activity name is the same as the tag of the XML element that defines that activity
        self.tag = tag
        self.name = tag
        
        # Unique index for each activity
        self.index = index
        # Unique id for each activity
        self.id = index.replace('-', '')
        # Layer number of activity
        self.layer = index.count('-')

        self.parent_act = parent_act
        # Decide if this activity is unused
        self.is_unused = is_unused
        # A dictionary to hold all check results
        # {checkItem: comment}
        self.check_result = dict()
        # Flag if this activity can hold other activity
        self.isContainer = False

        # To connect activity, not used at the moment 
        self.ref_id = None
        self.has_ref_id = False
        self.ref_to = None
        self.has_ref_to = False

        # Attribute dictionary of activity
        self.attrib = attrib
        # Skip if attribute is not a dictionary
        self.hasAttrib = isinstance(
            self.attrib, dict) if not self.attrib is None else False

        # Some attribute is in the child node target
        self.target = None
        self.hasTarget = False

        # Child list
        self.childActs = list()
        self.hasChildActs = False

        self.displayName = "None"
        self.hasDisplayName = False

        self.screenshot = ""
        self.hasScreenshot = False

        self.filePath = None
        self.hasFilePath = False

        self.selector = None
        self.hasSelector = False

        self.text = None
        self.hasText = False

        # Variable dictionary with key: name, type, default, checkItem
        self.varDict = dict()
        self.hasVarDict = False

        # Tag:{type: , name:}
        # Argument dictionary with key: name, type, direction, default, checkItem
        self.argDict = dict()
        self.hasArgDict = False

        self.sendWindowMessages = None
        self.hasSendWindowMessages = False

        self.simulateClick = None
        self.hasSimulateClick = False

        self.simulateType = None
        self.hasSimulateType = False

        # Values of assign activity
        self.assignTo = ""
        self.assignValue = ""

        self.delayBefore = None
        self.delayMS = None
        self.delayAfter = None
        self.delayBetweenKeys = None
        self.delay = None
        self.hasDelayBefore = False
        self.hasDelayMS = False
        self.hasDelayAfter = False
        self.hasDelayBetweenKeys = False
        self.hasDelay = False

        self.excel_range = None
        self.has_excel_range = False

        self.add_headers = None
        self.has_add_headers = False

        self.extractChildActs(node)
        self.extractTarget(node)

        self.annotation = None
        self.hasAnnotation = False

        self.logMessage = None
        self.hasLogMessage = False
        # invoke workflow filename
        self.workflowFileName = None
        self.hasWorkflowFileName = False

        self.encoding = None
        self.hasEncoding = False

        self.logLevel = None
        self.delayDict = dict()

        # Asset name of Get Credential activity
        self.assetName = None
        self.assetValue = None

        # Condition of if or while
        self.condition = ""

        # Key and Key Modifiers of Send Hotkey
        self.key = None
        self.hasKey = False
        self.keyModifiers = None
        self.hasKeyModifiers = False

        self.hasPassword = False

        self.isSpecialKey = False
        
        # output activity when error happened
        try:
            self.initAttrib(node)
        except Exception as e:
            logger.error(r" _____ ____  ____   ___  ____  _ ")
            logger.error(r"| ____|  _ \|  _ \ / _ \|  _ \| |")
            logger.error(r"|  _| | |_) | |_) | | | | |_) | |")
            logger.error(r"| |___|  _ <|  _ <| |_| |  _ <|_|")
            logger.error(r"|_____|_| \_\_| \_\\___/|_| \_(_)")
            logger.error("")
            logger.error("Fail to initialize this activity: " + str(self))
            logger.error("Internal path: " + self.getInternalPath())
            logger.exception(e)
        
        self.checkEmptySequence()
        # To output attributes of activity
        self.strAttrib = ""
        self.hasStrAttrib = False
        self.getAvailableAttribs()
        self.checkUnusedAct()
        self.checkDisplayName()
        self.checkNotTopFlowchart()
        self.checkScreenshot()

    def extractChildActs(self, node):
        '''

        '''
        # For level 1 node, get the childNode
        if self.is_unused:
            return list()
        elif self.name in Act.lv1ActNodeList:
            self.isContainer = True
            self.childActs = getChildActs(node, self.index, self)
        # For level 2 node, get seq nodes
        elif self.name in Act.lv2ActNodeList:
            self.isContainer = True
            # For level 2 node, sub sequence's tag can other than 'sequence'
            sequenceNodeList = getSequenceNodeList(node)
            if len(sequenceNodeList) > 0:
                childActList = list()
                childIndex = 1
                for sequenceNode in sequenceNodeList:
                    if sequenceNode.tag in Act.actList:
                        childActList.append(Act(sequenceNode.tag,
                                                sequenceNode.attrib,
                                                self.index + '-' +
                                                (childIndex),
                                                self,
                                                sequenceNode))
                        childIndex += 1
                    else:
                        childActList += getChildActs(sequenceNode,
                                                     self.index, self, childIndex - 1)
                        childIndex += 1
                if len(childActList) > 0:
                    self.childActs = childActList
                else:
                    self.childActs = list()
        self.hasChildActs = len(self.childActs) > 0

    def initAttrib(self, node):
        if self.hasAttrib:
            if "FilePath" in self.attrib.keys():
                self.filePath = self.attrib["FilePath"]
                self.hasFilePath = True
                self.properties['FilePath'] = self.attrib["FilePath"]
            if "Path" in self.attrib.keys():
                self.filePath = self.attrib["Path"]
                self.hasFilePath = True
                self.properties['Path'] = self.attrib["Path"]
            if "FileName" in self.attrib.keys():
                self.filePath = self.attrib["FileName"]
                self.hasFilePath = True
                self.properties['FileName'] = self.attrib["FileName"]
            if "WorkbookPath" in self.attrib.keys():
                self.filePath = self.attrib["WorkbookPath"]
                self.hasFilePath = True
                self.properties['WorkbookPath'] = self.attrib["WorkbookPath"]
            if "DisplayName" in self.attrib.keys():
                self.displayName = self.attrib["DisplayName"]
                if len(self.displayName) > 0:
                    self.hasDisplayName = True
                self.properties['DisplayName'] = self.attrib["DisplayName"]
            if 'SendWindowMessages' in self.attrib.keys():
                self.hasSendWindowMessages = True
                if self.attrib["SendWindowMessages"] == 'True':
                    self.sendWindowMessages == True
                self.properties['SendWindowMessages'] = self.attrib["SendWindowMessages"]
            if "SimulateClick" in self.attrib.keys():
                self.hasSimulateClick = True
                if self.attrib["SimulateClick"] == 'True':
                    self.simulateClick = True
                # Checks whether the click uses SimulateClick or SendWindowMessages
                if not (self.simulateClick or self.sendWindowMessages):
                    self.check_result["checkClick"] = Act.commentDict["checkClick"]
                self.properties['SimulateClick'] = self.attrib["SimulateClick"]
            if "SimulateType" in self.attrib.keys():
                self.hasSimulateType = True
                if self.attrib["SimulateType"] == 'True':
                    self.simulateType = True
                # Checks whether the type uses SimulateType or SendWindowMessages
                if not (self.simulateType or self.sendWindowMessages):
                    self.check_result["checkType"] = Act.commentDict["checkType"]
                self.properties['SimulateType'] = self.attrib["SimulateType"]
            if "Annotation.AnnotationText" in self.attrib.keys():
                self.annotation = self.attrib["Annotation.AnnotationText"]
                if len(self.annotation) > 0:
                    self.hasAnnotation = True
                self.properties['Annotation'] = self.attrib["Annotation.AnnotationText"]
            if "WorkflowFileName" in self.attrib.keys():
                self.hasWorkflowFileName = True
                self.workflowFileName = self.attrib["WorkflowFileName"]
                # Checks whether the workflow file is in a folder outside the project folder.
                if '..' in self.workflowFileName:
                    self.check_result['checkExternalRef'] = Act.commentDict['checkExternalRef'].format(
                        self.workflowFileName)
                self.properties['WorkflowFileName'] = self.attrib["WorkflowFileName"]
            if "Text" in self.attrib.keys():
                self.hasText = True
                self.text = self.attrib["Text"]
                self.properties['Text'] = self.attrib["Text"]
            if "Encoding" in self.attrib.keys():
                self.hasEncoding = True
                self.encoding = self.attrib["Encoding"]
                self.properties['Encoding'] = self.attrib["Encoding"]
            if "DelayBefore" in self.attrib.keys():
                self.hasDelayBefore = True
                delayBefore = self.attrib["DelayBefore"]
                try:
                    self.delayBefore = int(delayBefore) / 1000
                    self.checkDelay("DelayBefore", self.delayBefore)
                    self.delayDict["DelayBefore"] = self.delayBefore
                except ValueError:
                    self.delayBefore = 0
                self.properties['DelayBefore'] = self.attrib["DelayBefore"]
            if "DelayMS" in self.attrib.keys():
                self.hasDelayMS = True
                delayMS = self.attrib["DelayMS"]
                try:
                    self.delayMS = int(delayMS) / 1000
                    self.checkDelay("DelayMS", self.delayMS)
                    self.delayDict["DelayMS"] = self.delayMS
                except ValueError:
                    self.delayMS = 0
                self.properties['DelayMS'] = self.attrib["DelayMS"]
            if "DelayAfter" in self.attrib.keys():
                self.hasDelayAfter = True
                delayAfter = self.attrib["DelayAfter"]
                try:
                    self.delayAfter = int(delayAfter) / 1000
                    self.checkDelay("DelayAfter", self.delayAfter)
                    self.delayDict["DelayAfter"] = self.delayAfter
                except ValueError:
                    self.delayAfter = 0
                self.properties['DelayAfter'] = self.attrib["DelayAfter"]
            if "DelayBetweenKeys" in self.attrib.keys():
                self.hasDelayBetweenKeys = True
                delayBetweenKeys = self.attrib["DelayBetweenKeys"]
                try:
                    self.delayBetweenKeys = int(delayBetweenKeys) / 1000
                    self.checkDelay("DelayBetweenKeys", self.delayBetweenKeys)
                    self.delayDict["DelayBetweenKeys"] = self.delayBetweenKeys
                except ValueError:
                    self.delayBetweenKeys = 0
                self.properties['DelayBetweenKeys'] = self.attrib["DelayBetweenKeys"]
            if "Selector" in self.attrib.keys():
                self.selector = self.attrib["Selector"]
                self.hasSelector = True
                # self.checkSelector()
                self.properties['Selector'] = self.attrib["Selector"]
            if "KeyModifiers" in self.attrib.keys():
                self.keyModifiers = self.attrib["KeyModifiers"]
                if self.keyModifiers != "Null":
                    self.hasKeyModifiers = True
                self.properties['KeyModifiers'] = self.attrib["KeyModifiers"]
            if "Password" in self.attrib.keys():
                if self.attrib["Password"] != "{Null}":
                    self.hasPassword = True
                self.properties['Password'] = self.attrib["Password"]
            if "Name" in self.attrib.keys():
                self.ref_id = self.attrib['Name']
                self.has_ref_id = True
                self.properties['Name'] = self.attrib["Name"]
            if 'Key' in self.attrib.keys():
                self.key = self.attrib['Key']
                if self.key != "Null":
                    self.hasKey = True
                self.properties['Key'] = self.attrib["Key"]
            if 'Cell' in self.attrib.keys():
                self.excel_range = self.attrib['Cell']
                self.has_excel_range = True
                self.properties['Range'] = self.attrib['Cell']
            if 'StartingCell' in self.attrib.keys():
                self.excel_range = self.attrib['StartingCell']
                self.has_excel_range = True
                self.properties['Range'] = self.attrib['StartingCell']
            if 'Range' in self.attrib.keys():
                self.excel_range = self.attrib['Range']
                self.has_excel_range = True
                self.properties['Range'] = self.attrib['Range']
            if 'AddHeaders' in self.attrib.keys():
                self.add_headers = self.attrib['AddHeaders']
                self.has_excel_range = True
                self.properties['AddHeaders'] = self.add_headers
            if 'InformativeScreenshot' in self.attrib.keys():
                self.screenshot = self.attrib["InformativeScreenshot"]
                self.hasScreenshot = True
                self.properties['InformativeScreenshot'] = self.attrib["InformativeScreenshot"]
            if 'SpecialKey' in self.attrib.keys():
                self.isSpecialKey = eval(self.attrib["SpecialKey"])
                self.properties['SpecialKey'] = self.attrib["SpecialKey"]
            if Act.inputProperties:
                for prop in Act.inputProperties:
                    if prop in self.attrib.keys():
                        self.properties[prop] = self.attrib[prop]

        if self.hasTarget:
            if "InformativeScreenshot" in self.target.keys():
                self.screenshot = self.target["InformativeScreenshot"]
                self.hasScreenshot = True
                self.properties['InformativeScreenshot'] = self.target["InformativeScreenshot"]
            if "Selector" in self.target.keys():
                self.selector = self.target["Selector"]
                self.hasSelector = True
                # self.checkSelector()
                self.properties['Selector'] = self.target["Selector"]
            if Act.inputProperties:
                for prop in Act.inputProperties:
                    if prop in self.target.keys():
                        self.properties[prop] = self.target[prop]

        if self.name == "Delay":
            if "Duration" in self.attrib.keys():
                self.hasDelay = True
                try:
                    self.delay = parseDuration(self.attrib["Duration"])
                    self.checkDelay("Delay", self.delay)
                except ValueError:
                    self.delay = 0
                self.properties['Duration'] = self.attrib["Duration"]
            else:
                self.check_result["checkDelay"] = "This delay has no value."
        elif self.name == "LogMessage":
            self.hasLogMessage = True
            
            # Skip old version log message
            if "Message" in self.attrib:
                self.logMessage = self.attrib["Message"]
            else:
                logger.warning("Skip the old version Log Message.")
                self.logMessage = ""
            self.logLevel = self.attrib["Level"]
            if self.logLevel == "Error":
                # Checks whether the log message is outside the Catch block of a TryCatch.
                if not self.is_in_scope("TryCatch.Catches"):
                    self.check_result["checkErrorLogOutsideCatch"] = Act.commentDict["checkErrorLogOutsideCatch"]
        elif self.name == "Assign":
            if node.getchildren() is None:
                self.is_unused = True
            else:
                for child in node.getchildren():
                    if child.tag == "Assign.To":
                        self.assignTo = child.getchildren()[0].text
                    elif child.tag == "Assign.Value":
                        self.assignValue = child.getchildren()[0].text
        elif self.name == "GetRobotAsset":
            self.assetName = self.attrib["AssetName"]
            # Recommends to double check if the Get Asset activity is not being used to retrieve a password.
            self.check_result["checkGetAsset"] = Act.commentDict["checkGetAsset"].format(
                self.assetName)
            self.properties['AssetName'] = self.attrib["AssetName"]
        elif self.name in ["If", "While", "DoWhile"]:
            if "Condition" in self.attrib.keys():
                self.condition = self.attrib["Condition"]
        elif self.name == "GetPassword":
            # Recommends the use of Get Credential instead of Get Password.
            self.check_result["checkGetPassword"] = Act.commentDict["checkGetPassword"]
        elif self.name == "Parallel":
            # Recommends to double check if the parallel activity is properly used.
            self.check_result["checkParallel"] = Act.commentDict["checkParallel"]
        elif self.name in ["AppendRange", "GetTableRange", "ReadCellFormula", "ReadRange", "ReadCell", "ReadColumn", "ReadRow", "WriteRange", "WriteCell"]:
            # Warns that an activity related to Excel uses password.
            if self.hasPassword:
                self.check_result["checkExcelActWithPassword"] = Act.commentDict["checkExcelActWithPassword"]
        elif self.name == "OpenApplication":
            # Checks Internet Explorer is being opened with Open Application activity instead of Open Browser activity.
            if 'iexplore' in self.filePath:
                self.check_result["checkIeInOpenApp"] = Act.commentDict["checkIeInOpenApp"]
        elif self.name == "TryCatch":
            # Checks whether there is a nested TryCatch.
            if self.is_in_scope("TryCatch.Catches"):
                self.check_result["checkTryInCatch"] = Act.commentDict["checkTryInCatch"]
        elif self.name == 'ExcelReadRange':
            try:
                self.excel_range = node.getchildren()[0].getchildren()[
                    0].getchildren()[0].attrib['Value']
                self.has_excel_range = True
            except Exception:
                logger.info('Skip older version of Excel Read Range.')
        elif self.name == 'CommentOut':
            self.is_unused = True

    def checkDelay(self, delayType, duration):
        '''
        Check whether a used delay is greater than the indicated threshold (duration).
        If it is, checks whether the delay has annotations, which will determine the level of the check: delays without annotation should be fixed to include annotations, and delays with annotation should be double checked.
        '''
        if duration > Act.checkBmk["delayBmk"]:
            if not self.hasAnnotation:
                self.check_result["check" + delayType] = Act.commentDict["checkDelay"].format(
                    delayType, duration)
            else:
                self.check_result["check" + delayType + "WithAnnotation"] = Act.commentDict["checkDelayWithAnnotation"].format(
                    delayType, duration, self.annotation)

    def extractTarget(self, node):
        '''
        Checks whether the element representing an activity has the target element as its child. The target element contains information like selector and screenshot file name of the activity.
        '''
        if not node is None:
            for child in node:
                if "TargetObject" in child.tag:
                    continue
                if "Target" in child.tag:
                    self.target = child.find('Target').attrib
                    self.hasTarget = True

    def __str__(self):
        return "[" + self.index + ", " + self.name + "," + self.displayName + "]"

    def checkDisplayName(self):
        '''
        Checks if a sequence is using its default name or a more descriptive name (recommended).
        '''
        if self.name == "Sequence":
            if self.hasDisplayName:
                if self.displayName in ["Sequence", "Do"]:
                    self.check_result["checkDisplayName"] = Act.commentDict["checkDisplayName"]
            else:
                if self.name in ["Sequence"]:
                    self.check_result["checkDisplayName"] = Act.commentDict["checkDisplayName"]

    def checkVarName(self):
        '''
        Checks whether variables in a workflow follows a certain naming pattern.
        The pattern can be specified using regular expressions.
        '''
        try:
            varPattern = Act.checkBmk["varPattern"]
        except KeyError:
            varPattern = 0
        re_camel_case = r"(?:_?[A-Z][A-Za-z0-9]+)*"
        # 1 type_var skip Japanese        
        if varPattern == 1:
            for varName, varUnit in self.varDict.items():
                type = varUnit["Type"]
                type = extract_type(type)
                if type in Act.typeDict.keys():
                    # Check if only alphabet number underscore
                    if re.fullmatch(r"[A-Za-z0-9_]+", varName):
                        pattern = r"^" + \
                            re.escape(Act.typeDict[type]) + re_camel_case
                        if not re.fullmatch(r"[A-Z][A-Z0-9]+", varName) is None:
                            continue
                        elif re.fullmatch(pattern, varName) == None:
                            varUnit["checkName"] = Act.commentDict["checkName1"].format(
                                varName, Act.typeDict[type])
                    else:
                        if not varName.startswith(Act.typeDict[type]):
                            varUnit["checkName"] = Act.commentDict["checkName1"].format(
                                varName, Act.typeDict[type])
                else:
                    logger.warning(
                        "'{0}' is skipped for it is not in the dictionary.".format(varUnit["Type"]))
        # 2 type var
        elif varPattern == 2:
            for varName, varUnit in self.varDict.items():
                type = varUnit["Type"]
                type = extract_type(type)
                if type in Act.typeDict.keys():
                    pattern = r"^" + \
                        re.escape(Act.typeDict[type]) + re_camel_case
                    if re.fullmatch(pattern, varName) == None:
                        varUnit["checkName"] = Act.commentDict["checkName1"].format(
                            varUnit, Act.typeDict[type])
                else:
                    logger.warning(
                        "'{0}' is skipped for it is not in the dictionary.".format(varUnit["Type"]))
        # 3 var
        else:
            pattern = re_camel_case
            for varName, varUnit in self.varDict.items():
                if re.fullmatch(pattern, varName) is None:
                    varUnit["checkName"] = Act.commentDict["checkName1"].format(
                        varName)

    def checkArgName(self):
        '''
        Checks whether arguments in a workflow follows a certain naming pattern.
        The pattern can be specified using regular expressions.
        '''
        try:
            argPattern = Act.checkBmk["argPattern"]
        except KeyError:
            argPattern = 0
        re_camel_case = r"(?:_?[A-Z][A-Za-z0-9]+)+"
        # 1 arg_type_var skip Japanese
        if argPattern == 1:
            for argName, argUnit in self.argDict.items():
                type = argUnit["Type"]
                type = extract_type(type)
                if type in Act.typeDict.keys():
                    # Check if only alphabet number underscore
                    if re.fullmatch(r"[A-Za-z0-9_]+", argName):
                        pattern = r"(arg|a_)" + \
                            re.escape(Act.typeDict[type]) + re_camel_case
                        if re.fullmatch(pattern, argName) == None:
                            argUnit["checkName"] = Act.commentDict["checkName1"].format(
                                argName, "(arg|a_)" + Act.typeDict[type])
                    else:
                        if not (argName.startswith("arg" + Act.typeDict[type]) or argName.startswith("a_" + Act.typeDict[type])):
                            argUnit["checkName"] = Act.commentDict["checkName1"].format(
                                argName, "(arg|a_)" + Act.typeDict[type])
                else:
                    logger.warning(
                        "'{0}' is skipped for it is not in the dictionary.".format(argUnit["Type"]))
        # 2 arg_type var
        elif argPattern == 2:
            for argName, argUnit in self.argDict.items():
                type = argUnit["Type"]
                type = extract_type(type)
                if type in Act.typeDict.keys():
                    pattern = r"^arg" + \
                        re.escape(Act.typeDict[type]) + re_camel_case
                    if re.fullmatch(pattern, argName) == None:
                        argUnit["checkName"] = Act.commentDict["checkName1"].format(
                            argName, "(arg|a_)" + Act.typeDict[type])
                else:
                    logger.warning(
                        "'{0}' is skipped for it is not in the dictionary.".format(argUnit["Type"]))
        # 3 arg_var
        elif argPattern == 3:
            pattern = r"(arg|a_)" + re_camel_case
            for argName, argUnit in self.argDict.items():
                if re.fullmatch(pattern, argName) is None:
                    argUnit["checkName"] = Act.commentDict["checkName1"].format(
                        argName, "(arg|a_)")
        # 4 var
        else:
            pattern = r"[a-z]+(?:[A-Z][a-z0-9]+)+"
            for argName, argUnit in self.argDict.items():
                if re.fullmatch(pattern, argName) is None:
                    argUnit["checkName"] = Act.commentDict["checkName0"].format(
                        argName)

    def checkScreenshot(self):
        '''
        Checks whether the screenshot file for used in the activity exists.
        If there is no associated screenshot or the screenshot file is not found, checks whether annotations are used instead to explain the implementation.
        '''
        if self.name in Act.uiActList:
            if self.hasScreenshot:
                if not os.path.exists(Act.screenshotFolder + self.screenshot + ".png"):
                    if self.hasAnnotation:
                        self.check_result["checkScreenshotWithAnnotation"] = Act.commentDict["checkScreenshotWithAnnotation"].format(
                            self.annotation)
                    else:
                        self.check_result["checkScreenshot"] = Act.commentDict["checkScreenshot"].format(
                            self.screenshot)
            else:
                if self.hasAnnotation:
                    self.check_result["checkScreenshotWithAnnotation"] = Act.commentDict["checkScreenshotWithAnnotation"].format(
                        self.annotation)
                else:
                    self.check_result["checkScreenshot"] = Act.commentDict["checkScreenshot"].format(
                        self.screenshot)

        ## Possible refactoring:
        # if self.name in Act.uiActList:
        #     if not self.hasScreenshot or not os.path.exists(Act.screenshotFolder + self.screenshot + ".png"):
        #         if self.hasAnnotation:
        #             self.check_result["checkScreenshotWithAnnotation"] = Act.commentDict["checkScreenshotWithAnnotation"].format(
        #                 self.annotation)
        #         else:
        #             self.check_result["checkScreenshot"] = Act.commentDict["checkScreenshot"].format(
        #                 self.screenshot)

    def checkSelector(self):
        '''
        Checks whether the selector contains the idx attribute.
        '''
        if "idx" in self.selector:
            self.check_result["checkSelector"] = Act.commentDict["checkSelector"]

    def setVarDict(self, varDict):
        '''
        Extracts variables used in the activity and checks their naming patterns
        '''
        self.varDict = varDict
        self.hasVarDict = True
        self.checkVarName()

    def setArgDict(self, argDict):
        '''
        Extracts arguments used in the activity and checks their naming patterns
        '''
        if len(argDict) > 0:
            self.argDict = argDict
            self.hasArgDict = True
            self.checkArgName()

    def checkEmptySequence(self):
        '''
        Checks whether a sequence is empty (i.e., has no activities inside it).
        '''       
        if self.name == "Sequence" and not self.hasChildActs:
            self.check_result["checkEmptySequence"] = Act.commentDict["checkEmptySequence"].format(
                self.displayName)

    def getAvailableAttribs(self):
        '''
        Creates a string with information about the attributes of an activity.
This string will be used as a comment attached to the activity list in the Code Analyzer report.
        '''
        strAttrib = ""
        if self.hasDelay:
            strAttrib += "Delay: " + str(self.delay) + "\n"
        if self.hasDelayAfter:
            strAttrib += "DelayAfter: " + str(self.delayAfter) + "\n"
        if self.hasDelayBefore:
            strAttrib += "DelayBefore: " + str(self.delayBefore) + "\n"
        if self.hasDelayBetweenKeys:
            strAttrib += "DelayBetweenKeys: " + \
                str(self.delayBetweenKeys) + "\n"
        if self.hasDelayMS:
            strAttrib += "DelayMS:" + str(self.delayMS) + "\n"
        if self.hasText:
            strAttrib += "Text: " + self.text + "\n"
        if self.hasEncoding:
            strAttrib += "Encoding: " + self.encoding + "\n"
        if self.hasSelector:
            strAttrib += "Selector: " + self.selector + "\n"
        if len(strAttrib) > 0:
            self.hasStrAttrib = True
            self.strAttrib = strAttrib

    def getInternalPath(self):
        '''
        Recursively obtains the hierarchy path from the root activity to the current one.
        '''
        if self.displayName == "None":
            name = self.name
        else:
            name = self.displayName
        if self.parent_act is None:
            return name
        else:
            return self.parent_act.getInternalPath() + ">" + name

    def checkUnusedAct(self):
        '''
        Checks whether an activity is not being used.
        '''
        if self.is_unused:
            self.check_result["checkUnusedAct"] = Act.commentDict["checkUnusedAct"]

    def checkNotTopFlowchart(self):
        '''
        Checks whether flowcharts are being used other than in the first layer (level) of the workflow hierarchy.
        '''
        if self.layer > 0 and self.name == "Flowchart":
            self.check_result["checkNotTopFlowchart"] = Act.commentDict["checkNotTopFlowchart"]

    # If activity is a sub activity of
    def is_in_scope(self, act_name):
        if self.parent_act is None:
            return False
        elif self.parent_act.name == act_name:
            return True
        else:
            return self.parent_act.is_in_scope(act_name)

    def set_ref_id(self, ref_id):
        self.ref_id = ref_id

def extractVarDict(act, node):
    '''
    Extracts the variables used in the activity (node) passed as parameter.
    Outputs a dictionary with the variables' names and values.
    '''
    varDict = dict()
    if len(node.getchildren()) > 0:
        for child in node:
            name = child.attrib["Name"]
            type = child.attrib["TypeArguments"]
            varUnit = dict()
            varUnit["Type"] = type

            varUnit["Default"] = child.attrib["Default"] if "Default" in child.attrib else ""
            varUnit["Annotation"] = child.attrib["Annotation.AnnotationText"] if "Annotation.AnnotationText" in child.attrib else ""

            varUnit["Activity"] = act
            varDict[name] = varUnit
    return varDict

def extractArgDict(act, node):
    '''
    Extracts arguments passed to an Invoke Workflow activity.
    '''
    argDict = dict()
    for argNode in node:
        if len(argNode.attrib.values()) == 1:
            continue
#         type, argName = argNode.attrib.values()
        type = argNode.attrib["TypeArguments"]
        argName = argNode.attrib["xKey"]
        type = re.sub(r"\w+:", "", type)
        argUnit = dict()
        argUnit["Direction"] = argNode.tag
        argUnit["Type"] = type
        argUnit["Default"] = argNode.text if not argNode.text is None else ""
        argUnit["Activity"] = act
        # set annotation as "" because no annotation can be found here
        argUnit["Annotation"] = ""
        argDict[argName] = argUnit
    return argDict

def extractRootArgDict(root, node):
    '''
    Extracts arguments passed to a workflow.    
    '''
    rootArgNode = node.find('Members')
    if rootArgNode is None:
        return dict()
    argDict = dict()
    prefix = node.attrib['Class']
    for childNode in rootArgNode.getchildren():
        argName = childNode.attrib["Name"]
        typeArgument = childNode.attrib["Type"]
        if '(' in typeArgument:
            direction, type = typeArgument.split("(", 1)
            type = type.replace(")", "", 1)
        else:
            direction = 'Property'
            type = typeArgument
        default = ""
        if (prefix + '.' + argName) in node.attrib.keys():
            default = node.attrib[prefix + '.' + argName]
        argUnit = dict()
        argUnit["Direction"] = direction
        argUnit["Type"] = type
        argUnit["Default"] = default
        argUnit["Activity"] = root
        argUnit["Annotation"] = childNode.attrib["Annotation.AnnotationText"] if "Annotation.AnnotationText" in childNode.attrib else ""
        argDict[argName] = argUnit
    return argDict

def getChildActs(node, prefix, parent_act, childIndex=0, is_unused=False):
    '''
    Extract activities inside the activity passed as a parameter (XML node).
    It also extracts variables and arguments used in the activity and initializes dictionaries with their names and values.
    '''
    actList = list()
    index = 1 + childIndex
    for child in node:
        if child.tag in ["ActivityAction.Argument", "DebugSymbol.Symbol", "Reference"]:
            continue

        # Extract variables used in this activity
        if ("Variables" in child.tag):
            varDict = extractVarDict(parent_act, child)
            if len(varDict) > 0:
                parent_act.setVarDict(varDict)
            continue

        # Extract arguments used in this activity
        # Do activities have arguments defined in them as well? *TO CHECK*
        if ("Argument" in child.tag):
            argDict = extractArgDict(parent_act, child)
            if len(argDict) > 0:
                parent_act.setArgDict(argDict)
            continue
        
        if child.tag in ["FlowStep", "FlowStep.Next", "Flowchart.StartNode"]:
            if node.tag == "Flowchart":
                childList = getChildActs(child, prefix, parent_act, index - 1, True)
                actList += childList
                index += len(childList)
            else:
                childList = getChildActs(child, prefix, parent_act, index - 1)
                actList += childList
                index += len(childList)
                if child.tag == 'FlowStep':
                    if len(childList) > 0 and 'Name' in child.attrib.keys():
                        childList[0].set_ref_id(child.attrib['Name'])
            continue
        if child.tag in ["FlowDecision", "FlowSwitch"]:
            is_unused = False
        act = Act(child.tag,
                  child.attrib,
                  prefix + '-' + str(index),
                  parent_act,
                  child,
                  is_unused)
        actList.append(act)
        index += 1
    return actList

def getSequenceNodeList(node):
    '''
    Extracts the list of nodes of a sequence.
    '''
    nodeList = list()
    for child in node:
        nodeName = re.sub(r"\{....\}", '', child.tag)
        if nodeName in Act.nodeCheckList:
            nodeList.append(child)
    if len(nodeList) > 0:
        return nodeList
    for child in node:
        for grandChild in child:
            nodeName = re.sub(r"\{....\}", '', grandChild.tag)
            if nodeName in Act.nodeCheckList:
                nodeList.append(grandChild)
    return nodeList

def getFullList(act):
    '''
    Recursively creates a list with the activity passed as parameter and all of its descendants.
    '''
    fullList = list()
    fullList.append(act)
    if act.hasChildActs:
        for childAct in act.childActs:
            fullList = fullList + getFullList(childAct)
    return fullList

def getSubActs(act):
    '''
    Recursively creates a list of all activities that are descendants of the activity passed as parameter.
    '''
    subActList = list()
    if act.hasChildActs:
        for childAct in act.childActs:
            subActList.append(childAct)
            subActList += getSubActs(childAct)
    return subActList

def parseDuration(strDelay):
    '''
    Parse the delay from the format HH:MM::SS to milliseconds.
    '''
    if len(strDelay) == 8:
        hour, minute, second = strDelay.split(":")
        return int(hour) * 3600 + int(minute) * 60 + int(second)
    else:
        hour, minute, secondMS = strDelay.split(":")
        return int(hour) * 60 * 60 + int(minute) * 60 + float(secondMS)

def checkLogMessageInSequece(sequence):
    '''
    Checks whether a sequence starts and ends with a log message.
    '''
    if sequence.hasChildActs:
        firstChild = sequence.childActs[0]
        lastChild = sequence.childActs[-1]
        if not checkIfLogMessage(firstChild):
            firstChild.check_result["checkSequenceStartLog"] = Act.commentDict["checkSequenceStartLog"].format(
                firstChild.index)
        if not checkIfLogMessage(lastChild):
            lastChild.check_result["checkSequenceEndLog"] = Act.commentDict["checkSequenceEndLog"].format(
                lastChild.index)

def checkLogMessageInFlowchart(flowchart):
    '''
    Checks whether there are log messages in a flowchart.    
    '''
    for act in extract_1st_layer_in_flowchart(flowchart):
        if act.name == "Sequence":
            checkLogMessageInSequece(act)
        elif act.name == 'TryCatch':
            act = checkLogMessageInTry(act)


def checkLogMessageInTry(try_act):
    '''
    Checks whether there are log messages in the sequence inside the Try block of a TryCatch.
    '''
    if try_act.hasChildActs:
        first_child_act = try_act.childActs[0]
        if first_child_act.name == 'TryCatch.Try' and first_child_act.hasChildActs:
            first_grandchild_act = first_child_act.childActs[0]
            if first_grandchild_act.name == 'Sequence':
                checkLogMessageInSequece(first_grandchild_act)
                return first_grandchild_act
            else:
                checkLogMessageInSequece(first_child_act)
                return None
        else:
            return None
    else:
        return None

def extract_1st_layer_in_flowchart(flowchart):
    '''
    Extracts activities in the first layer (level) of the hierarchy started by a flowchart (branches will create additional levels).
    '''
    act_list = list()
    skip_list = list()
    for sub in getSubActs(flowchart):
        if sub in skip_list:
            continue
        if sub.name in ['FlowDecision', 'FlowDecision.True', 'FlowDecision.False', 'FlowSwitch', 'FlowSwitch.Default']:
            continue
        act_list.append(sub)
        if sub.isContainer:
            skip_list = getSubActs(sub)
    return act_list

def checkIfLogMessage(act):
    '''
    Checks whether the activitiy is a log message or implements a logging mechanism (e.g., invoked workflow used for logging).
    '''
    if act.name == 'LogMessage':
        return True
    elif act.name == 'InvokeWorkflowFile':
        if 'log' in act.displayName or 'Log' in act.displayName or 'ログ' in act.displayName:
            return True
        else:
            return False
    elif act.name in ['TerminateWorkflow', 'Throw', 'Rethrow']:
        return True
    else:
        return False

def extract_type(type):
    '''
    Formats data type names.
    '''
    type = re.sub(r"\(.+\)", "", type)
    type = re.sub(r"[a-z]+:", "", type)
    if '[]' in type:
        type = 'Array'
    return type
