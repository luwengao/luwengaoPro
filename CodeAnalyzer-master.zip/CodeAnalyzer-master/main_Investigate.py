'''
Created on Oct 24, 2017

@author: Frank She
'''

import datetime
import json
import os
import logging

import xlsxwriter

from lib.init_funcs import startCheck
from lib.investigate_funcs import write_issue_list, write_project_stat, write_activities_details

exec_path = os.getcwd()

if not os.path.exists('report'):
    os.mkdir('report')
if not os.path.exists('log'):
    os.mkdir('log')

log_fmt = '%(asctime)s %(levelname)s:%(message)s'

log_file = exec_path + '/log/' + str(datetime.date.today()) + '.log'

logging.basicConfig(
    format=log_fmt,
    level=logging.DEBUG,
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler()
    ])

logger = logging.getLogger(__name__)

# Current Working Directory
VERSION = "ver0.98_internal"
logger.info("Code Analyzer " + VERSION)

report_path = exec_path + "/report"

project_folder = input(
    "Please input the project folder, or input exit to end the program.\n")

project_files_dict = dict()
project_files_dict['main_exist'] = False
project_files_dict['project.json'] = False
project_files_dict['main'] = ''
project_files_dict["root"] = list()
cw_list = list()

for root, dirs, files in os.walk(project_folder):
    for file in files:
        if file.endswith('.xaml'):
            cw_list.append(os.path.join(root, file))

project_files_dict["common"] = cw_list

project = startCheck(project_files_dict, project_folder)

wfList = project.wfList

workbook = xlsxwriter.Workbook(report_path + "/CodeAnalyzer_" + VERSION +
                               "_" + project.projectFolder + "_" + str(datetime.date.today()) + ".xlsx")

write_project_stat(workbook, project)

write_issue_list(workbook, project)

write_activities_details(workbook, project)

workbook.close()
