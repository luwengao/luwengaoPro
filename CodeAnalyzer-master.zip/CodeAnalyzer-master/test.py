'''
Created on Oct 29, 2017

@author: fshe
'''
# import json
import tkinter as tk
from gui.Analysis import Analysis
from gui.MainFrame import MainFrame
from gui.Investigation import Investigation
# print(re.search(r'\(.*\)', "InArgument(x:String)"))
# print(re.search(r'\(.*\)', "x:String"))
# from collections import Counter

# pa = "(?:[A-Z][a-z0-9]+(_| ))*[A-Z][a-z0-9]+\.xaml"
# pa = r"([0-9]{2}(_[0-9]{2})*\.)?([A-Z][A-Za-z0-9]+)(?:(_| )[A-Z][A-Za-z0-9]+)*(_[0-9]{8})?\.xaml"
# pa = r"(?:_?[A-Z][A-Za-z0-9]+)*"
# workflow prefix
# pa = r"([0-9]{2}(_[0-9]{2})*\.)?"

# pa = r"[a-z]+:"
# workflowList = ["Clear Database.xaml", "01.Open Intra.xaml", "01_01.GetDLFile.xaml", "01_02.GetDlFile.xaml"]
# workflowList = ["Get_Transaction_DataAAB", "_Open_Intra", "_GetDLFile", "_GetDlF_ile.xaml"]

# workflowList = ["01.", "01_01.", "01_01_01.", "020_01_02."]
# for xaml in workflowList:
#     sh = re.fullmatch(pa, xaml)
#     # sh = re.sub(pa, "" , "InitializeLog_20170510.xaml")
#     print(sh)

root = tk.Tk()
# func_dict = dict()
# func_dict['analyze_code'] = print
# func_dict['investigate_code'] = print
# main = MainFrame(root, func_dict)
main = Investigation(root, 'Investigation', print)
main.mainloop()

