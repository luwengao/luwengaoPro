'''
Created on Mar 8, 2017

@author: Frank She
'''

import datetime
import json
import logging
import os
import shutil
import sys

from lib.draw_flowchart_funcs import draw_flowchart
from lib.init_funcs import extractXamlFiles, startCheck
from lib.write_checklist_funcs import writeChecklist
from lib.write_xlsx_funcs import writeResultAsXlsx

# Get execute path
exec_path = os.getcwd()

if not os.path.exists('report'):
    os.mkdir('report')
if not os.path.exists('log'):
    os.mkdir('log')


log_fmt = '%(asctime)s %(levelname)s:%(message)s'

log_file = exec_path + '/log/' + str(datetime.date.today()) + '.log'

logging.basicConfig(
    format=log_fmt,
    datefmt='%m-%d %H:%M',
    level=logging.DEBUG,
    handlers=[
        logging.FileHandler(log_file) #,
        # logging.StreamHandler()
    ])

logger = logging.getLogger(__name__)

settings = json.load(open("config/settings.json"))
outputChecklist = settings["outputChecklist"]
VERSION = settings['Version']

logger.info("Code Analyzer " + VERSION)
logger.info("Let me know if any questions.")
logger.info("Email: frank.she@uipath.com")
logger.info(
    "Please be noted that the check result can only be used for reference.")

args = sys.argv
if(not len(args) in [3,4]):
    logger.error("Please use input directory, output directory, and check item json file as parameters")
    sys.exit(1)  

for directory in args[1:]:
    if not os.path.exists(directory):
        logger.error("Directory:'{}' is not exists".format(directory))
        sys.exit(1)

report_path = args[2]
# PROJECT_FOLDER = "/home/fshe/Downloads/HpiCode/GDL_CA_Brz_Brazil_SpecialCustomers_SAPtoQueue"
PROJECT_FOLDER = args[1]

check_item_json = None
if(len(args) == 4):
    check_item_json = json.load(open(args[3]))

PROJECT_FILE_DICT = extractXamlFiles(PROJECT_FOLDER)
PROJECT = startCheck(PROJECT_FILE_DICT, PROJECT_FOLDER)
output_folder = report_path + PROJECT.projectFolder
if os.path.exists(output_folder):
    shutil.rmtree(output_folder)
os.mkdir(output_folder)

if check_item_json is None:
    writeResultAsXlsx(PROJECT, report_path, VERSION)
else:
    writeResultAsXlsx(PROJECT, report_path, VERSION, check_item_json)

# if outputChecklist == 'True' :
#     writeChecklist(PROJECT, exePath, settings["robotFolder"])

draw_flowchart(PROJECT, report_path, VERSION)
