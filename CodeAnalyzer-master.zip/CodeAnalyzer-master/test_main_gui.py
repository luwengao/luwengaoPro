'''
Created on Nov 25, 2017

@author: Frank She
'''

import tkinter as tk


def start_analyze():
    analyze_frame = tk.Toplevel()

    check_var1 = tk.BooleanVar()
    check_var2 = tk.BooleanVar()
    check_var1.set(False)
    check_var2.set(False)

    def check_function():
        print(check_var1.get())
        print(check_var2.get())
    C1 = tk.Checkbutton(
        analyze_frame,
        text="Music",
        variable=check_var1,
        height=5,
        width=20,
        command=check_function)
    C2 = tk.Checkbutton(   
        analyze_frame,
        text="Video",
        variable=check_var2,
        height=5,
        width=20)

    check_value = tk.Button(
        analyze_frame,
        text='Check',
        command=check_function
    )
    C1.pack()
    C2.pack()
    check_value.pack()
    analyze_frame.mainloop()

class MainFrame(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.pack()
        self.create_widgets()

    def create_widgets(self):
        self.analyze = tk.Button(
            self, 
            text='Analyze a Project',
            width=30,
            bd=2,
            command=self.do_analyze)
        self.analyze_and_report = tk.Button(
            self, 
            text='Analyze a Project and Fill in Check List',
            width=30)
        self.investigate = tk.Button(
            self, 
            text='Investigate Specified Activities',
            width=30)

        self.analyze.pack(side='top')
        self.analyze_and_report.pack(side='top')
        self.investigate.pack(side='top')

        self.quit = tk.Button(self, text="QUIT", fg="red",
                              command=root.destroy)
        self.quit.pack(side="bottom")

    def do_analyze(self):
        root.destroy()
        start_analyze()

    def do_analyze_and_report(self):
        pass

    def do_investigation(self):
        pass

root = tk.Tk()
app = MainFrame(master=root)
app.master.title('Code Analyzer Ver1.00')
app.mainloop()


