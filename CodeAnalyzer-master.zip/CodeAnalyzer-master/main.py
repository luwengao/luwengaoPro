'''
Created on Oct 24, 2017

@author: Frank She
'''

import datetime
import json
import logging
import os
import shutil

from lib.init_funcs import extractXamlFiles, inputProjectFolder, startCheck
from lib.write_checklist_funcs import writeChecklist
from lib.write_xlsx_funcs import writeResultAsXlsx

# Get execute path
exec_path = os.getcwd()

if not os.path.exists('report'):
    os.mkdir('report')
if not os.path.exists('log'):
    os.mkdir('log')

# Current Working Directory

log_fmt = '%(asctime)s %(levelname)s:%(message)s'

log_file = exec_path + '/log/' + str(datetime.date.today()) + '.log'

logging.basicConfig(
    format=log_fmt, 
    level=logging.DEBUG,
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler()
    ])

logger = logging.getLogger(__name__)

settings = json.load(open("config/settings.json"))
outputChecklist = settings["outputChecklist"]
VERSION = settings['Version']

logger.info("Code Analyzer "+ VERSION)
logger.info("Let me know if any questions.")
logger.info("Email: frank.she@uipath.com")
logger.info("Please be noted that the check result can only be used for reference.")

report_path = exec_path + "/report/"

while True:
    project_folder = inputProjectFolder()
    project_files_dict = extractXamlFiles(project_folder)
    project = startCheck(project_files_dict, project_folder)

    output_folder = report_path + project.projectFolder
    if os.path.exists(output_folder):
        shutil.rmtree(output_folder)
    os.mkdir(output_folder)
    writeResultAsXlsx(project, report_path, VERSION)

    if outputChecklist == 'True' :
        writeChecklist(project, exec_path, settings["robotFolder"])
