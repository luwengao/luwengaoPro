$(function(){
	$('#dataview').tablefix({width:1500,height:710,fixRows:1,fixCols:2});
	$('#dataview_bk').tablefix({width:800,height:600,fixRows:2,fixCols:2});
});
