$(function(){
	$('.mod1_table table').tablefix({width:800,height:600,fixRows:1,fixCols:1});
});

$(document).ready(function(){
	$(".mod1_table table td,.mod1_table table th").hover(function(){
		$(this).not('th').addClass('hover');
		$(this).siblings().not('th').addClass('hover');
		var index=$(this).index();
		$(this).closest('table').find('tr').each(function(){if($('td, th',this).size()>0){$('td, th',this).eq(index).not('th').addClass('hover');}});
	},function(){
		$(this).removeClass('hover');
		$(this).siblings().not('th').removeClass('hover');
		var index=$(this).index();
		$(this).closest('table').find('tr').each(function(){
			if($('td, th',this).size()>0){
				$('td, th',this).eq(index).not('th').removeClass('hover');
			}
		});
	});
});
