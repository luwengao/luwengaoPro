$(function(){
//(function($){
	var Limg = $('#leftImage');
	var Rimg = $('#rightImage');
	var Lwidth = Limg.scrollWidth;
	var Rwidth = Rimg.scrollWidth;

	Rimg.scroll(
		function() {
			Limg.scrollTop(Rimg.scrollTop());//縦スクロール連動
			Limg.scrollLeft(Rimg.scrollLeft());//横スクロール連動
		});

	Limg.scroll(
		function() {
			Rimg.scrollTop(Limg.scrollTop());//縦スクロール連動
			Rimg.scrollLeft(Limg.scrollLeft());//横スクロール連動
		});

	var Limg2 = $('#leftImage2');
	var Rimg2 = $('#rightImage2');
	var Lwidth2 = Limg2.scrollWidth;
	var Rwidth2 = Rimg2.scrollWidth;

	Rimg2.scroll(
		function() {
			Limg2.scrollTop(Rimg2.scrollTop());//縦スクロール連動
			Limg2.scrollLeft(Rimg2.scrollLeft());//横スクロール連動
		});

	Limg2.scroll(
		function() {
			Rimg2.scrollTop(Limg2.scrollTop());//縦スクロール連動
			Rimg2.scrollLeft(Limg2.scrollLeft());//横スクロール連動
		});

	var tabs = document.getElementById('tabcontrol').getElementsByTagName('a');
	var pages = document.getElementById('tabbody').getElementsByClassName('tab');
	function changeTab() {
		// ▼href属性値から対象のid名を抜き出す
		var targetid = this.href.substring(this.href.indexOf('#')+1,this.href.length);
		// ▼指定のタブページだけを表示する
		for(var i=0; i<pages.length; i++) {
			if( pages[i].id != targetid ) {
				pages[i].style.display = "none";
			}
			else {
				pages[i].style.display = "block";
			}
		}
		// ▼クリックされたタブを前面に表示する
		for(var i=0; i<tabs.length; i++) {
			tabs[i].style.zIndex = "0";
		}
		this.style.zIndex = "10";
		// ▼ページ遷移しないようにfalseを返す
		return false;
	}

	// ▼すべてのタブに対して、クリック時にchangeTab関数が実行されるよう指定する
	for(var i=0; i<tabs.length; i++) {
		tabs[i].onclick = changeTab;
	}
	// ▼最初は先頭のタブを選択
	changeTab.call(tabs[0]);
});
