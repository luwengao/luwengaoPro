$(function() {
	$("#export").click(function(){
		downLoadJson(document.getElementById( 'export' ).title);
	});
});

function downLoadJson(content) {
	var text = content;
	var blob = new Blob([text], {type: "text/plain"});
	var a = document.createElement("a");
	a.href = URL.createObjectURL(blob);
	a.target = '_blank';
	a.download = '対象外文字.txt';
	a.click();
}
