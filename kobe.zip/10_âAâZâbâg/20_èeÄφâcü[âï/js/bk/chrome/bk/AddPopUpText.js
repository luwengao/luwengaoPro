function getPopUpText(){



	return document.body.innerText;


};