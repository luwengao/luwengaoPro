function getPopUpText(){
			
	var str = "";

	function getInnerText(dom){
	
		try{

			for(var i = 0; i < dom.childNodes.length; i++){
			var item = dom.childNodes[i];
			
			var pipe = false;
				
				/* �e�L�X�g�m�[�h */
				if(item.nodeType == 3){	
					var trimText = item.nodeValue.replace(/\s+/g," ").replace(/\n/g,"").trim().replace(/\t+/g," ");
				
					if(trimText != ""){
						str += trimText;
					}
				}
				/* �v�f�m�[�h */
				else if(item.nodeType == 1){
					
					
					
					/* �\���m�[�h���� */
					var style = window.getComputedStyle(item);
					
					if(style.display == "none" ||
						style.visibility == "hidden" ||
						style.hidden == "true" ||
						item.hidden == true ||
						item.type == "hidden"){
							pipe = false;
					}else{
						/* �^�O���� */
						if(item.nodeName == "IFRAME"){
							getInnerText(item.contentWindow.document.body);
						}
						
						/* �O���b�h */
						else if(item.nodeName == "WJ-MULTI-ROW" ){
							
							var cell = "";
							var header = "";
							
							for(var node of item.firstChild.childNodes){

								//ColumnHeader
								if(node.getAttribute("wj-part") == "ch"){
									
									for(var hRows of node.firstChild.childNodes){//�w�b�_�[�s����
										
										for(var col of hRows.childNodes){//�w�b�_�[��
											
											header += col.textContent.replace(/\s+/g," ").replace(/\n/g,"").trim().replace(/\t+/g," ") + "|";
										}
										header += "\r\n";
									}
								}
								//Cells
								else if(node.getAttribute("wj-part") == "root"){
									for(var cRows of node.firstChild.childNodes){//�s����
										var CRLF = false;
										for(var col of cRows.childNodes){//�񐔕�
											if(col.getAttribute("role") == "gridcell"){
												CRLF = true;												
												cell += col.textContent.replace(/\s+/g," ").replace(/\n/g,"").trim().replace(/\t+/g," ") + "|";
											}
										}
										if(CRLF) cell += "\r\n";
									}
								}
							}
							str += header + cell;
						}
						/* �O���b�h�ȊO */
						else{

							
							if(item.nodeName == "SELECT"){
							
								for(var opt of item.children){
									if(opt.value == item.value){
										str += opt.textContent;
									}else{
										//str += "��" + opt.textContent + " ";
									}
								}

							}
							else if(item.nodeName == "TEXTAREA") {
								if(item.value == ""){
									 str += "";
								}else{
									str += item.value;
								}
							}
							else if(item.type == "radio"){
								if(item.checked){
									str += "��";
								}else{
									str += "��";
								}
							}
							else if(item.type == "checkbox"){
								if(item.checked){
									str += "��";
								}else{
									str += "��";
								}
							}

							//�{�^���v�f
							else if(item.nodeName == "BUTTON" || item.type == "button" || item.type == "submit"){
								if(item.value == ""){
									str += "";
								}else{
									str += item.value;
								}
							}
							//INPUT����
							else if(item.nodeName == "INPUT" && item.type != "hidden"){
								if(item.value != ""){
									str += item.value;
								}else{ 
									str += "";
								}
								
							}
							else if(item.nodeName == "LI"){
								if(item.parentElement.nodeName == "UL"){
									str += "�E";
									getInnerText(item);
								}
								if(item.parentElement.nodeName == "OL"){
									str += ([].slice.call(item.parentElement.children).indexOf(item) + 1) + ".";
									getInnerText(item);
								}
							}
											
							else if(item.nodeName == "SCRIPT" || item.nodeName == "NOSCRIPT"){
								
							}
							else{
								getInnerText(item);
							}
							if(item.nodeName == "TD" && window.getComputedStyle(item).border.indexOf("0px") == -1){
								str += "|";
							}
						}

						
						
						/* ���s�^�O�ݒ� */
						var onCRLF = false;
						
						
						//grid��class��wj-group-end���܂�ł���Ή��s
						if(item.nodeName == "TR" ||
							item.nodeName == "LI" ||
							item.nodeName == "P" ||
							item.nodeName == "H1" ||
							item.nodeName == "H2" ||
							item.nodeName == "H3" ||
							item.nodeName == "H4" ||
							item.nodeName == "H5" ||
							item.nodeName == "H6" ||
							item.nodeName == "FOOTER" ||
							item.classList.contains("wj-group-end")
						 ) {
						 	onCRLF = true;
						}
						//<br>��td�̒��ɂȂ���Ή��s
						if(item.parentElement.nodeName != "TD"&& item.nodeName == "BR"){
							onCRLF = true;
						}
						//display:block�Ȃ���s
						if(window.getComputedStyle(item).display == "block"){
							onCRLF = true;
						}
						//li�v�f�̒��ɓ����Ă���Ή��s
						if(item.parentElement.nodeName == "LI"){
							onCRLF = true;
						}
						
						
						if(onCRLF) str += "\r\n";
						
						
						
						
					}

				}
				else if(item.nodeType == 8){
					pipe = false;
				}
				
				
				/* �p�C�v���� */
				if(pipe == true){
					str += "|";
				}		

			}
		}catch(e){
			str += "[ERROR]" + e.message + "\r\n";
		}	
	}
		
	getInnerText(document.body);



		
	return str;
	
};



