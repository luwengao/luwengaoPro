function getPopUpText(){
	return document.body.innerText.replace(/\n/g,"\r\n");
};