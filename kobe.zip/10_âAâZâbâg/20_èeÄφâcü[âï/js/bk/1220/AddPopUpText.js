function getPopUpText(){


	/* �u���E�U���� */
	var userAgent = window.navigator.userAgent.toLowerCase();
	var browser = "";
	
	if(userAgent.indexOf('msie') != -1 || userAgent.indexOf('trident') != -1 ) {
		browser = "IE";
		
	} else if(userAgent.indexOf('edge') != -1) {
		browser = "Edge";
		
	} else if(userAgent.indexOf('chrome') != -1) {
		browser = "Chrome"
		
	} else if(userAgent.indexOf('safari') != -1) {
		browser = "Safari";
		
	} else if(userAgent.indexOf('firefox') != -1) {
		browser = "FireFox";
		
	} else if(userAgent.indexOf('opera') != -1) {
		browser = "Opera";
	} else {
		browser = "Ohter";
	}

	function getStyle(item){
		var style ;
		if(browser == "IE"){
			style = item.currentStyle;
		}else{
			style = window.getComputedStyle(item);	
		}
	
		return style;
	}


			
	var str = "";
	


	function getInnerText(dom){
	
		try{
		
			var focusItem = document.activeElement;

			for(var i = 0; i < dom.childNodes.length; i++){
			var item = dom.childNodes[i];
			
			
				/* �e�L�X�g�m�[�h */
				if(item.nodeType == 3){	
					var trimText = item.nodeValue.replace(/\s+/g," ").replace(/\n/g,"").replace(/\t+/g," ").replace(/^\s+|\s+$/g,"");
				
					if(trimText != ""){
						str += trimText;
					}
				}
				/* �v�f�m�[�h */
				else if(item.nodeType == 1){
					
					
					
					/* �\���m�[�h���� */
					var style = getStyle(item);
					 					
					if(style.display != "none" &&
						style.visibility != "hidden" &&
						style.hidden != "true" &&
						item.hidden != true &&
						item.type != "hidden"){

						/* �^�O���� */
						if(item.nodeName == "IFRAME"){
							getInnerText(item.contentWindow.document.body);
						}
						
						/* wijmo�O���b�h */
						else if(item.nodeName == "APP-MULTI-ROW" || item.nodeName == "APP-FLEX-GRID"){
							
							var cell = "";
							var header = "";
							
							for(var a = 0; a < item.firstChild.childNodes.length; a++){
								var node = item.firstChild.childNodes[a];

								//ColumnHeader
								if(node.getAttribute("wj-part") == "ch"){
									
									for(var b = 0; b < node.firstChild.childNodes.length; b++){//�w�b�_�[�s����
										var hRows = node.firstChild.childNodes[b];
										
										for(var c = 0; c < hRows.childNodes.length; c++){//�w�b�_�[��
											var col =  hRows.childNodes[c];
											
											header += col.textContent.replace(/\s+/g," ").replace(/\n/g,"").replace(/\t+/g," ").replace(/^\s+|\s+$/g,"") + "|";
										}
										header += "\r\n";
									}
								}
								//Cells
								else if(node.getAttribute("wj-part") == "root"){
									for(var b = 0; b < node.firstChild.childNodes.length; b++){//�s����
										var cRows =  node.firstChild.childNodes[b];
										
										var CRLF = false;
										for(var c = 0; c < cRows.childNodes.length; c++){//�񐔕�
											var col = cRows.childNodes[c];
											if(col.getAttribute("role") == "gridcell"){
												CRLF = true;												
												cell += col.textContent.replace(/\s+/g," ").replace(/\n/g,"").replace(/\t+/g," ").replace(/^\s+|\s+$/g,"") + "|";
											}
										}
										if(CRLF) cell += "\r\n";
									}
								}
							}
							str += header + cell;
						}
						/* �O���b�h�ȊO */
						else{
						
							if(item == focusItem){
								str += "��";
							}

							
							if(item.nodeName == "SELECT"){
							
								for(var a = 0; a < item.children.length; a++){
									var opt = item.children[a];
									if(opt.value == item.value){
										str += opt.textContent;
									}else{
										//str += "��" + opt.textContent + " ";
									}
								}

							}
							else if(item.nodeName == "TEXTAREA") {
								if(item.value == ""){
									 str += "";
								}else{
									str += item.value;
								}
							}
							else if(item.type == "radio"){
								if(item.checked){
									str += "��";
								}else{
									str += "��";
								}
							}
							else if(item.type == "checkbox"){
								if(item.checked){
									str += "��";
								}else{
									str += "��";
								}
							}

							//�{�^���v�f
							else if(item.nodeName == "BUTTON" || item.type == "button" || item.type == "submit"){
								if(item.value == ""){
									str += "";
								}else{
									str += item.value;
								}
							}
							//INPUT����
							else if(item.nodeName == "INPUT" && item.type != "hidden"){
								if(item.value != ""){
									str += item.value;
								}else{ 
									str += "";
								}
								
							}
							else if(item.nodeName == "LI"){
								if(item.parentElement.nodeName == "UL"){
									str += "�E";
									getInnerText(item);
								}
								if(item.parentElement.nodeName == "OL"){
									str += ([].slice.call(item.parentElement.children).indexOf(item) + 1) + ".";
									getInnerText(item);
								}
							}
							else if(item.nodeName == "IMG"){
								str += "�摜["+item.alt + "]\r\n";
							}
											
							else if(item.nodeName == "SCRIPT" || item.nodeName == "NOSCRIPT"){
								
							}
							else{
								getInnerText(item);
							}
							//�e�[�u������i�\�Ƃ��ė��p���Ă���ꍇ�j
							if(item.nodeName == "TD" || item.nodeName == "TH"){
								var table = item.parentElement.parentElement.parentElement;
								var style = getStyle(table);
								if(style.border !== undefined){
									if((style.border.indexOf("0px") == -1  && style.border != "" )|| (style.borderRightWidth != "0px" && style.borderRightWidth != "")){
									str += "|";
								}
								}

							}
						}

						
						
						/* ���s�^�O�ݒ� */
						var onCRLF = false;
						
						
						//grid��class��wj-group-end���܂�ł���Ή��s
						if(item.classList !== undefined){ 
							if(item.classList.contains("wj-group-end")){
								onCRLF = true;
							}
						}
						
						if(item.nodeName == "TR" ||
							item.nodeName == "P" ||
							item.nodeName == "H1" ||
							item.nodeName == "H2" ||
							item.nodeName == "H3" ||
							item.nodeName == "H4" ||
							item.nodeName == "H5" ||
							item.nodeName == "H6" ||
							item.nodeName == "FOOTER"
						 ) {
						 	onCRLF = true;
						}
						
						
						
						//<br>��td�̒��ɂȂ���Ή��s
						if(item.parentElement.nodeName != "TD"&& item.nodeName == "BR"){
							onCRLF = true;
						}
						
						//display:block/table-row/list-item�Ȃ���s
						var style = getStyle(item);
						
						if(style.display == "block" ||
						style.display == "list-item" ||
						style.display == "table-row" ||						
						style.display == "table-row-group" ||
						style.display == "table-header-group" ||
						style.display == "table-footer-group" ||
						style.display == "table-caption" ){
							onCRLF = true;
						}
						//li�v�f�̒��ɓ����Ă���Ή��s
						if(item.nodeType == 3 && item.parentElement.nodeName == "LI"){
							onCRLF = true;
						}
						
						
						if(onCRLF){
							str += "\r\n";
						}
						
						
						
						
					}

				}
	

			}
		}catch(e){
			str += "[ERROR]" + e.message + "\r\n";
		}	
		
	}
		
	getInnerText(document.body);
	
	str += "��:Focus ��:Checkbox ��:Radio" + "\r\n";
	//str += "URL:"  + window.location.href + "\r\n"; 
	//str += "TAB��:"  + document.title + "\r\n"; 
		
	return str;
	
};



