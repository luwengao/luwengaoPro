function getPopUpText(){




/*	var convArray = [];


	var inputs = Array.prototype.slice.call(document.querySelectorAll("div,nav"));

	//style������visible�ɂ��Ă���p�^�[��
	inputs = inputs.filter(function(input,index,array){
		
		var styled = window.getComputedStyle(input);
		if(styled.visibility === "hidden"){
			return input;
		}
		/*
		if(input.style.visibility === "visible" && input.style.display !== "none"){
					return input;
		}else if(input.visibility === "visible" && input.display !== "none"){
					return input;
		}
	});

		for(var input of inputs){
		var conv = {};
		conv["id"] = input.id;
	}


	var returnText = "";

	if(inputs.length > 0){
		
		inputs.forEach(function(v){
			returnText = returnText + v.innerText + "\r\n";
		});
	}



	return returnText;
*/

	return document.body.innerText;


};